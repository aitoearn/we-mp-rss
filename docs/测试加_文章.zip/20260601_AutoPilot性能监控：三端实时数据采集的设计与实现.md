# AutoPilot 性能监控：三端实时数据采集的设计与实现

![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_001_5f3ce7b3890e5276.jpg)

# AutoPilot 性能监控：三端实时数据采集的设计与实现

原创
xinxi
xinxi
[测试加](javascript:void(0);)

![]()
在小说阅读器读本章
去阅读
![]()
在小说阅读器中沉浸阅读

# AutoPilot 性能监控：三端实时数据采集的设计与实现

## 一、为什么要自建性能采集

### 现有工具的困境

移动端性能测试领域，主流方案大致分两类：

**商业工具 —— 以 PerfDog 为代表**

PerfDog 是腾讯出品的专业性能测试工具，功能强大、数据精确，业内认可度高。但对于团队日常使用存在现实门槛：

- •
  **按设备/时长收费**
  — 企业版价格不低，对小团队或高频使用场景成本压力大
- •
  **独立运行**
  — 无法与自动化测试流程集成，只能人工手动操作
- •
  **黑盒**
  — 无法定制采集逻辑或集成到自研平台中

**开源工具 —— 以 SoloX 为代表**

SoloX 是一个开源的移动端性能数据采集工具，支持 Android 和 iOS，Web 界面实时展示，基本能满足日常性能监控需求。

但问题是：  **SoloX 已经停止维护了。**

这带来了几个直接影响：

- •
  **iOS 17+ 完全不可用**
  — iOS 17 移除了传统的 lockdown 通信通道，SoloX 依赖的 tidevice 无法连接新版 iOS 设备
- •
  **Bug 无人修复**
  — GitHub Issues 堆积，社区 PR 无人合并
- •
  **依赖过时**
  — Python 依赖版本固化，与新版工具链冲突
- •
  **独立运行**
  — 作为独立工具，无法与自动化测试流程联动

### AutoPilot 的思路

既然要做一个整合平台，性能监控自然不能缺席。我们的目标：

1. 1.
   **三端支持**
   — Android / iOS / HarmonyOS 统一采集
2. 2.
   **iOS 17+ 兼容**
   — 通过 RemoteXPC + tunneld 方案支持最新 iOS 版本（包括 iOS 26）
3. 3.
   **实时可视化**
   — WebSocket 推送 + 高性能时序图表
4. 4.
   **与自动化联动**
   — 在自动化测试执行的同时，可手动开启性能采集，操作与性能数据时间轴对齐
5. ![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_004_9ff509aa89a50fa3.png)

---

## 二、功能使用

### 2.1 操作流程

性能监控的使用非常简单，三步完成：

**第一步：选择设备和应用**

在顶部工具栏选择已连接的设备（自动识别平台类型），然后点击「刷新应用」获取设备上已安装的应用列表，选择目标应用。

**第二步：配置采集参数**

勾选需要监控的指标：

- •
  **CPU**
  — 应用 CPU 占比 + 系统 CPU 总负载
- •
  **内存**
  — 应用 PSS 内存（Android 额外提供 Java Heap / Native Heap / SWAP）
- •
  **FPS**
  — 帧率 + Jank 次数
- •
  **网络**
  — 收发流量（KB/s）
- •
  **GPU**
  — GPU 占用率
- •
  **电池**
  — 电量百分比 + 温度
- •
  **温度**
  — 设备热区温度
- •
  **磁盘**
  — 存储使用情况

设置采集间隔（默认 1 秒，最低 0.5 秒）。

**第三步：开始采集**

点击「开始采集」，实时图表即刻展示。每个指标一张独立图表，数据点逐秒更新，最多展示最近 120 个数据点（即 2 分钟的滑动窗口）。

### 2.2 历史会话

每次采集自动创建一个会话（Session），停止后数据持久化到本地数据库。支持：

- • 历史会话列表（按时间倒序）
- • 历史数据回放（完整时序图表）
- • 统计摘要（每个指标的 AVG / MAX / MIN）
- • CSV 导出（用于进一步分析或报告）
- ![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_005_8b66b4dbdfc1761b.png)

### 2.3 平台差异

| 指标 | Android | iOS < 17 | iOS 17+ | HarmonyOS |
| --- | --- | --- | --- | --- |
| CPU（应用/系统） | ✅ | ✅ | ✅ | 规划中 |
| 内存（PSS） | ✅ | ✅ | ✅ | 部分（仅 Monkey 监控） |
| FPS + Jank | ✅ | ✅ | ✅ | 规划中 |
| GPU | ✅ | ✅ | ✅ | — |
| 网络流量 | ✅ | ✅ | ✅ | — |
| 电池/温度 | ✅ | — | — | — |

---

## 三、技术架构

### 3.1 分层架构

![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_006_c12097c28323ca2d.png)

### 3.2 数据流

![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_007_c4a8bc72d79044ff.png)

### 3.3 数据库设计

两张表，结构简洁：

```
-- 会话表：记录每次采集的元信息  
CREATE TABLE performance_sessions (  
    id TEXT PRIMARY KEY,           -- UUID  
    device_id TEXT NOT NULL,  
    device_type TEXT DEFAULT'adb',  
    package_name TEXT NOT NULL,  
    platform TEXT DEFAULT'Android',  
    metrics TEXT DEFAULT'[]',     -- JSON: ["cpu","memory","fps"]  
    status TEXT DEFAULT'running', -- running / stopped  
    started_at TEXT,  
    stopped_at TEXT,  
    summary_json TEXT              -- 采集结束后计算的统计摘要  
);  
  
-- 数据表：时序数据点  
CREATE TABLE performance_data (  
    id INTEGERPRIMARY KEY AUTOINCREMENT,  
    session_id TEXT NOT NULL,  
timestampREALNOT NULL,       -- Unix 时间戳  
    metric TEXT NOT NULL,          -- "cpu_app" / "mem_total" / "fps" ...  
valueREALNOT NULL,  
    extra TEXT,                    -- 扩展字段（如内存细分）  
FOREIGN KEY (session_id) REFERENCES performance_sessions(id)  
);  
  
CREATE INDEX idx_perf_data_session_ts ON performance_data(session_id, timestamp);
```

设计要点：

- •
  **宽表 vs 窄表**
  — 选择窄表（每行一个指标），灵活支持动态指标种类，查询时按 metric 过滤
- •
  **缓冲写入**
  — 不逐条写入，每 5 秒批量 flush，减少 I/O 压力
- •
  **会话摘要**
  — 停止时计算 AVG/MAX/MIN 存入 summary_json，列表页无需重复聚合

---

## 四、实现原理

### 4.1 统一调度器：PerfCollector

`PerfCollector`  是整个性能监控的心脏。它在独立线程中运行，按固定间隔轮询各平台采集器：

```
classPerfCollector:  
def__init__(self, platform, device_id, package_name, metrics, callback, interval=1.0):  
self._stop_event = threading.Event()  
self._collectors = self._init_collectors()  # 根据平台初始化采集器  

  
def_run(self):  
whilenotself._stop_event.is_set():  
            start = time.time()  
            data = {}  
for name, collector inself._collectors.items():  
                result = collector.collect()  
if result:  
                    data.update(result)  
if data:  
self.callback({"ts": time.time(), "data": data})  

# 精确控制采集间隔  

            elapsed = time.time() - start  
self._stop_event.wait(max(0, self.interval - elapsed))
```

**平台路由策略**  ：

- • Android → 实例化多个独立采集器（CPU、Memory、FPS…），每个负责一个指标
- • iOS → 实例化一个统一采集器（tidevice 或 iOS18Collector），内部管理多指标订阅

这个差异源于底层协议：Android 通过 adb shell 逐个命令获取，天然适合拆分；iOS 通过 Instruments 服务统一推送，拆分反而增加开销。

### 4.2 Android 采集原理

#### CPU 采集

```
classAndroidCPUCollector:  
defcollect(self):  

# 1. 应用 CPU：通过 top 命令获取进程 CPU 占比  

        output = adb_shell(f"top -n 1 -b | grep {self.package_name}", device_id)  

# 解析进程状态列后的 %CPU 字段  

  

# 2. 系统 CPU：通过 /proc/stat 计算  

        stat = adb_shell("cat /proc/stat | head -1", device_id)  

# cpu user nice system idle iowait irq softirq  

# CPU% = (total_diff - idle_diff) / total_diff * 100

```

系统 CPU 使用差值算法：记录上一次的 total 和 idle，通过前后差值计算瞬时利用率，避免累积值的误导。

#### 内存采集

```
classAndroidMemoryCollector:  
defcollect(self):  
        output = adb_shell(f"dumpsys meminfo {pid}", device_id)  

# 解析 TOTAL PSS（单位 KB → MB）  

# 额外提取 Java Heap / Native Heap / SWAP PSS

```

使用  `dumpsys meminfo`  而非  `/proc/{pid}/status`  ，因为前者提供 PSS（按比例分摊共享内存），更准确反映应用的实际内存占用。

#### FPS 采集（最复杂）

FPS 采集器实现了两种数据源的自动切换：

```
classAndroidFPSCollector:  
defcollect(self):  

# 1. 检查目标应用是否在前台  

        window = self._get_focus_window()  
if package_name notin window:  
return {"fps": 0, "jank": 0}  
  

# 2. 优先使用 SurfaceFlinger --latency（更精确）  

ifself._surface_name:  
            timestamps = self._get_sf_timestamps()  
else:  

# 退而求其次：gfxinfo framestats  

            timestamps = self._get_framestats()  
  

# 3. 计算 FPS 和 Jank  

        fps = (frame_count - 1) / time_span  
        jank = self._calculate_jank(timestamps)
```

**Jank 判定算法**  ：

```
def_calculate_jank(self, timestamps):  
for i inrange(4, len(timestamps)):  

# 计算前三帧的平均耗时  

        avg_3_frames = (前三帧耗时之和) / 3 * 2  
        current_frame_time = timestamps[i] - timestamps[i-1]  

# Jank 条件：当前帧耗时 > 前三帧平均的 2 倍 且 > 83.3ms（2 帧）  

if current_frame_time > avg_3_frames and current_frame_time > 83.3ms:  
            jank += 1
```

这个算法参考了 PerfDog 的 Jank 定义：不使用固定阈值（如 16.6ms），而是基于历史帧的相对变化来判定卡顿，更贴合用户的实际感知。

**Surface 自动发现**  ：

当应用窗口切换时，SurfaceFlinger 的 Surface Name 会变化。采集器通过  `dumpsys SurfaceFlinger --list`  搜索包含目标包名的 Surface，并验证其是否有有效数据。连续 10 次无新帧时触发重新查找。

### 4.3 iOS < 17 采集原理

对于 iOS 16 及以下版本，使用 tidevice 库：

```
from tidevice import Device, Performance, DataType  
  
classiOSCollector:  
def_ensure_started(self):  
        d = Device(self.device_id)  
self._perf = Performance(d, perfs=[DataType.CPU, DataType.MEMORY, DataType.FPS])  
self._perf.start(self.package_name, callback=self._on_data)  
  
def_on_data(self, data_type, data):  
if data_type == DataType.CPU:  
self._latest_data["cpu_app"] = data["value"]  
self._latest_data["cpu_sys"] = data["sys_value"]  
elif data_type == DataType.MEMORY:  
self._latest_data["mem_total"] = data["value"]  # MB  

elif data_type == DataType.FPS:  
self._latest_data["fps"] = data["value"]
```

tidevice 底层通过  **Instruments DTX 协议**  与 iOS 设备通信，订阅  `com.apple.instruments.server.services.sysmontap`  等服务获取实时性能数据。这是 Xcode Instruments 使用的同一套协议。

### 4.4 iOS 17+ 采集原理（核心突破）

#### 为什么 iOS 17 是分水岭

Apple 在 iOS 17 中做了一个重大的安全架构变更：

> **移除了 lockdown 服务的 USB 直连能力。**

在 iOS 16 及之前，第三方工具（tidevice、libimobiledevice）可以通过 USB 直接连接设备的 lockdownd 服务，协商加密通道后访问 Instruments 等开发者服务。

iOS 17 开始，设备通信改为  **RemoteXPC 架构**  ：

- • 设备在本地创建一个 TUN 隧道接口
- • 所有开发者服务通过这个隧道暴露
- • 必须先建立隧道连接，才能访问 Instruments 服务

这意味着 tidevice、SoloX 等依赖旧协议的工具全部失效。

#### AutoPilot 的解决方案

我们基于 pymobiledevice3 的底层协议实现，构建了完整的 iOS 17+ 性能采集链路：

![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_008_1ccf9dbafd47f99b.png)

#### 连接建立过程

```
classiOS18Collector:  
def_ensure_started(self):  

# 1. 通过 tunnel 地址连接设备的 Remote Service Discovery (RSD)  

        rsd = RemoteLockdownClient(self.tunnel_address)  
        rsd.connect()  
  

# 2. 在 RSD 之上建立 Instruments 服务通道  

        instrument = InstrumentServer(rsd).init()  
  

# 3. 创建高层设备对象  

self._device = PyiOSDevice(self.device_id, rpc_channel=instrument)  
  

# 4. 查找目标进程 PID  

        processes = self._device.get_processes()  
for proc in processes:  
if proc.get("bundleIdentifier") == self.package_name:  
self._target_pid = proc["pid"]  
break  
  

# 5. 订阅各性能服务  

self._device.start_get_graphics_fps(callback=self._on_fps)  
self._device.start_get_network(callback=self._on_network)  
self._device.start_get_system(callback=self._on_system)
```

#### 进程数据解析

iOS Instruments 的 sysmontap 服务返回的进程数据是一个  **定长数组**  ，字段顺序固定：

```
PROC_ATTRS = [  
'memVirtualSize', 'cpuUsage', 'procStatus', 'appSleep', 'uid',  
'vmPageIns', 'memRShrd', 'ctxSwitch', 'memCompressed', 'intWakeups',  
'cpuTotalSystem', 'responsiblePID', 'physFootprint', 'cpuTotalUser',  
'sysCallsUnix', 'memResidentSize', 'sysCallsMach', 'memPurgeable',  
'diskBytesRead', 'machPortCount', '__suddenTerm', '__arch', 'memRPrvt',  
'msgSent', 'ppid', 'threadCount', 'memAnon', 'diskBytesWritten',  
'pgid', 'faults', 'msgRecv', '__restricted', 'pid', '__sandbox'  
]  
  

# 通过索引直接定位关键字段  

IDX_CPU_USAGE = PROC_ATTRS.index('cpuUsage')           # → 1  

IDX_PHYS_FOOTPRINT = PROC_ATTRS.index('physFootprint') # → 12  

IDX_PID = PROC_ATTRS.index('pid')                      # → 32

```

收到 sysmontap 回调后，遍历所有进程，匹配目标 PID 提取 CPU 和内存：

```
def_on_system(self, data):  
for item in data:  
if"SystemCPUUsage"in item:  

# 系统总 CPU = CPU_TotalLoad / 核心数  

            cpu_total = item["SystemCPUUsage"]["CPU_TotalLoad"]  
self._latest_data["cpu_sys"] = cpu_total / item["CPUCount"]  
if"Processes"in item:  
for pid_str, values in item["Processes"].items():  
if values[IDX_PID] == self._target_pid:  
self._latest_data["cpu_app"] = values[IDX_CPU_USAGE]  

# physFootprint 单位是 Bytes → MB  

self._latest_data["mem_total"] = values[IDX_PHYS_FOOTPRINT] / 1024 / 1024
```

### 4.5 实时通信方案

#### 为什么选 WebSocket 而不是 SSE

性能数据推送频率为 1 次/秒，每次包含多个指标。对比：

| 方案 | 优势 | 劣势 |
| --- | --- | --- |
| SSE | 简单、HTTP 兼容 | 单向、无法从客户端控制 |
| WebSocket | 双向、低延迟 | 稍复杂 |
| 轮询 | 最简单 | 延迟高、浪费请求 |

选择 WebSocket 的原因：后续可能需要从前端发送控制指令（暂停/恢复/切换指标），双向通道更灵活。

#### 前端实现

```
// usePerfWs.js — WebSocket composable  
exportfunctionusePerfWs(sessionId, { maxPoints = 120 } = {}) {  
const series = ref({})  // 按指标名分组的时序数据  
  
  ws.onmessage = (e) => {  
const frame = JSON.parse(e.data)  // {ts, data: {cpu_app, mem_total, ...}}  
for (const [key, val] ofObject.entries(frame.data)) {  
// 滑动窗口：最多保留 120 个点  
      arr.push({ ts, value: val })  
if (arr.length > maxPoints) arr = arr.slice(-maxPoints)  
    }  
  }  
  
// 断线 2 秒后自动重连  
  ws.onclose = () => { setTimeout(connect, 2000) }  
}
```

图表使用 uPlot —— 一个极其轻量（< 35KB）但高性能的时序图表库，可以轻松处理每秒更新的实时数据，无 DOM 回流问题。

### 4.6 关键设计决策

#### 缓冲写入而非实时落盘

性能数据每秒产生 5-8 个数据点（取决于勾选的指标数），直接写 SQLite 会导致频繁的磁盘 I/O 和锁竞争。采用  **内存缓冲 + 5 秒批量 flush**  策略：

```
class_ActiveSession:  
defon_data(self, frame):  

# 写入内存缓冲区（线程安全）  

withself._buffer_lock:  
self._data_buffer.append((session_id, ts, metric, value, None))  

# 同时推送到 WebSocket（不等落盘）  

        asyncio.run_coroutine_threadsafe(self.broadcast(frame), self.loop)  
  
asyncdefflush_buffer(self):  

# 每 5 秒批量写入  

        batch = self._data_buffer[:]  
self._data_buffer.clear()  
await db.executemany("INSERT INTO performance_data ...", batch)
```

#### 同设备互斥

iOS 的 DVT 通道是独占资源，不能同时开两个 Instruments 连接。启动新会话时自动停止同设备的旧会话：

```
asyncdefstart_session(self, device_id, ...):  

# 停止同设备的已有会话  

for sid, sess inlist(self._sessions.items()):  
if sess.collector.device_id == device_id:  
awaitself.stop_session(sid)
```

#### 懒初始化

iOS 采集器使用懒初始化模式 —— 第一次调用  `collect()`  时才建立连接。这避免了会话创建阶段的长时间阻塞，也便于在连接失败时优雅降级。

---

## 五、与同类工具对比

| 维度 | PerfDog | SoloX | AutoPilot |
| --- | --- | --- | --- |
| 定位 | 商业专业工具 | 开源轻量工具 | 集成测试平台 |
| iOS 17+ 支持 | ✅ | ❌ 不支持 | ✅ RemoteXPC 方案 |
| 维护状态 | 持续更新 | 停止维护 | 持续迭代 |
| 费用 | 按设备/时长收费 | 免费 | 免费 |
| 与自动化联动 | ❌ 手动操作 | ❌ 手动操作 | ✅ 平台内联动 |
| 数据精度 | 高（底层 hook） | 中 | 中（系统命令 + Instruments） |
| 运行方式 | 独立客户端 | 独立 Web 服务 | 集成在桌面应用中 |
| FPS Jank 检测 | 专业级（多维度） | SurfaceFlinger 帧率 | SurfaceFlinger + gfxinfo 双源 + Jank 判定 |
| 可定制性 | ❌ 闭源 | ✅ 可改源码 | ✅ 自研可控 |
| 部署复杂度 | 安装即用 | 需 Python 环境 | 开箱即用 |
| HarmonyOS | ✅ | ❌ | ✅ |

**AutoPilot 的定位不是替代 PerfDog**  —— 在数据精度和专业性上，PerfDog 仍是行业标杆。AutoPilot 的价值在于：作为集成平台的一部分，提供  **免费、开箱即用、可与自动化流程联动**  的性能采集能力，覆盖日常开发和回归测试中 80% 的性能监控需求。

---

## 六、总结

性能监控看似简单（不就是定时读几个数据吗？），但要做到  **稳定、精确、三端统一**  ，细节非常多：

- • Android 的 FPS 采集需要处理 Surface 切换、窗口焦点判断、多数据源降级
- • iOS 17+ 的连接链路涉及 tunneld → RSD → DTX → Instruments 四层协议栈
- • 实时展示需要平衡推送频率、内存占用和数据库写入压力

AutoPilot 的性能监控模块不追求做一个「大而全」的性能平台，而是做到  **开箱即用、三端一致、与自动化天然联动**  。当自动化测试在执行用例时，性能数据同步采集，测试操作和性能表现一一对应 —— 这才是集成平台的真正价值。

---

*下一篇预告：《网络抓包与 Mock：移动端 HTTPS 流量捕获的工程实践》—— 如何在移动设备上做到无感抓包、SSL Pinning 绕过和请求篡改。*

预览时标签不可点
![]()

微信扫一扫   
 关注该公众号

继续滑动看下一个
轻触阅读原文
![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_010_b585214916937a92.png)
测试加
向上滑动看下一个

[知道了](javascript:;)

![]()
微信扫一扫
  
使用小程序
[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

×

分析

![]()
![](20260601_AutoPilot性能监控：三端实时数据采集的设计与实现_assets/img_013_b585214916937a92.png)

微信扫一扫可打开此内容，   
 使用完整服务

：
，
，
，
，
，
，
，
，
，
，
，
，
。
视频
小程序
赞
，轻点两下取消赞
在看
，轻点两下取消在看
分享
留言
收藏
听过