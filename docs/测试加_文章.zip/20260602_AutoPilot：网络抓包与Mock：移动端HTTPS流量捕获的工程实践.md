# AutoPilot：网络抓包与 Mock：移动端 HTTPS 流量捕获的工程实践

![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_001_bc024bb148f20b5e.jpg)

# AutoPilot：网络抓包与 Mock：移动端 HTTPS 流量捕获的工程实践

xinxi
xinxi
[测试加](javascript:void(0);)

![]()
在小说阅读器读本章
去阅读
![]()
在小说阅读器中沉浸阅读

# 网络抓包与 Mock：移动端 HTTPS 流量捕获的工程实践

> 如何在移动设备上做到无感抓包、SSL Pinning 绕过和请求篡改。

---

## 一、为什么移动端抓包这么难

在 PC 端抓包，打开 Chrome DevTools 或 Fiddler 就行了。但移动端的抓包是一个完全不同的问题：

**第一层障碍：HTTPS 加密。**  所有有意义的接口都走 HTTPS，中间人代理需要解密流量，这意味着你需要在设备上安装自定义 CA 证书。

**第二层障碍：SSL Pinning（少数 App）。**  部分安全要求较高的 App 会做证书绑定校验（Certificate Pinning），即使安装了 CA 证书，App 仍然拒绝被代理的连接。不过大多数 App 只要正确安装 CA 证书就能正常抓包。

**第三层障碍：环境配置。**  传统方案需要手动配置代理、手动安装证书、手动配置 Charles/mitmproxy ——步骤繁琐，新人上手困难。

**第四层障碍：数据篡改。**  测试容错场景时需要修改接口返回值（空数据、异常状态码、超时），传统方案要写 mitmproxy 脚本或配置 Charles Map Local，门槛不低。

AutoPilot 的抓包模块要解决的核心问题是：  **将这四层障碍全部封装到一键操作里，让测试工程师只关注测试本身。**

---

## 二、整体架构

![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_004_e7461f86167b8f63.png)

核心组件：

| 组件 | 职责 |
| --- | --- |
| **ProxyManager** | 代理会话生命周期管理（启动/停止/状态） |
| **FlowCaptureAddon** | mitmproxy 插件，拦截 request/response/error |
| **TamperEngine** | 请求/响应篡改引擎（数据篡改 + 网络故障模拟） |
| **Frida Manager** | SSL Pinning Bypass 的注入和管理 |
| **Device Proxy Setup** | 跨平台设备代理配置 |

---

## 三、MITM 代理核心实现

### 3.1 代理启动与线程模型

mitmproxy 的  `DumpMaster`  需要独占一个事件循环。我们的后端是 FastAPI (uvicorn)，已经有自己的 asyncio 事件循环。解决方案是将代理运行在  **独立的守护线程**  中：

```
class ProxyManager:  
 asyncdef start_session(self, device_id, device_type, port, ssl_enabled, host_filter):  

# 1. 创建会话记录写入 SQLite  

        session_id = str(uuid.uuid4())  
await execute("INSERT INTO proxy_sessions(...) VALUES(...)", [...])  
  

# 2. 获取主事件循环引用（用于跨线程通信）  

        main_loop = asyncio.get_running_loop()  
        session = _ActiveProxySession(session_id, main_loop)  
  

# 3. 启动异步 flush 任务（在主循环中）  

        session._flush_task = asyncio.create_task(session.start_flush_loop())  
        session._drain_task = asyncio.create_task(session._drain_queue())  
  

# 4. 代理在独立守护线程中运行  

self._thread = threading.Thread(  
            target=self._run_proxy,  
            args=(port, ssl_enabled, host_filter, main_loop, session),  
            daemon=True,  
        )  
self._thread.start()
```

代理线程内部：

```
def_run_proxy(self, port, ssl, host_filter, main_loop, session):  
from mitmproxy.tools.dump import DumpMaster  
  

# 独立事件循环  

    loop = asyncio.new_event_loop()  
    asyncio.set_event_loop(loop)  
  
    opts = options.Options(  
        listen_host="0.0.0.0",  
        listen_port=port,  
        ssl_insecure=True,  # 跳过上游证书验证  

    )  
  

# 注册自定义 Addon  

    addon = FlowCaptureAddon(session, main_loop, host_filter, tamper_engine)  
    master = DumpMaster(opts)  
    master.addons.add(addon)  
    loop.run_until_complete(master.run())
```

**关键设计决策：**

- •
  `ssl_insecure=True`
  ：对上游服务器跳过证书验证。因为我们的目的是抓包而非安全通信，这避免了上游证书链不完整导致的连接失败。
- • 守护线程（
  `daemon=True`
  ）：应用退出时代理线程自动终止，无需额外清理。
- • 双事件循环：代理线程有自己的
  `asyncio.new_event_loop()`
  ，通过
  `main_loop`
  引用实现跨线程的异步通信。

### 3.2 Flow 拦截与实时推送

`FlowCaptureAddon`  是 mitmproxy 的 addon，实现  `request()`  、  `response()`  、  `error()`  三个钩子：

```
classFlowCaptureAddon:  
def__init__(self, session, loop, host_filter, tamper_engine):  
self._session = session  
self._loop = loop  
self._host_filter = [h.lower() for h in host_filter] if host_filter else []  
self._tamper_engine = tamper_engine  
  
def_should_capture(self, flow) -> bool:  
"""Host 过滤：只捕获用户关心的域名"""  
ifnotself._host_filter:  
returnTrue  
        host = flow.request.pretty_host.lower()  
returnany(pattern in host for pattern inself._host_filter)  
  
defrequest(self, flow):  

# 1. 先执行网络故障注入（可能直接 kill flow）  

        fault_info = self._tamper_engine.apply_network_fault(flow)  
  

# 2. 非终端故障时，执行请求体篡改  

ifnot is_terminal_fault:  
            tamper_diff = self._tamper_engine.apply_to_request(flow)  
  

# 3. 序列化并推送到前端  

ifself._should_capture(flow):  
            data = _serialize_flow(flow)  
            data["faulted"] = Trueif fault_info elseFalse  
            data["tampered"] = Trueif tamper_diff elseFalse  
self._dispatch("request", data, flow)  
  
defresponse(self, flow):  

# 解码响应（处理 gzip/br 等编码）  

        flow.response.decode()  
  

# 限速模拟：按 body 大小计算 sleep 时间  

        throttle_rate = flow.metadata.get("throttle_rate_kbps")  
if throttle_rate and flow.response:  
            body_len = len(flow.response.raw_content orb"")  
            sleep_sec = body_len / (throttle_rate * 1024 / 8)  
            time.sleep(min(sleep_sec, 30))  
  

# 执行响应体篡改  

        tamper_diff = self._tamper_engine.apply_to_response(flow)  
self._dispatch("response", data, flow)
```

**跨线程通信方案：**  mitmproxy addon 运行在代理线程，WebSocket 推送需要在主线程的事件循环中执行。我们使用了一个线程安全的队列（  `deque`  +  `threading.Lock`  ）来桥接：

```
class_ActiveProxySession:  
defenqueue_flow(self, event_type, data, flow):  
"""代理线程调用：入队"""  
withself._queue_lock:  
self._queue.append((event_type, data, flow))  
  
asyncdef_drain_queue(self):  
"""主线程任务：每 100ms 批量消费队列"""  
whileTrue:  
await asyncio.sleep(0.1)  
            batch = []  
withself._queue_lock:  
whileself._queue:  
                    batch.append(self._queue.popleft())  
for event_type, data, flow in batch:  
awaitself.on_flow(event_type, data, flow)
```

这个设计保证了：

- • 代理线程的 addon 回调不阻塞（
  `enqueue_flow`
  是 O(1) 操作）
- • WebSocket 广播在主事件循环中执行（符合 FastAPI 的线程模型）
- • 100ms 的 drain 间隔对实时性足够好，同时避免过于频繁的锁竞争

### 3.3 数据持久化策略

每个完成的 flow（有 response 或 error）都写入 SQLite。为了避免高频 I/O：

```
def_queue_db_write(self, data, raw_flow):  
    row = (flow_id, session_id, ts, method, url, host, path,  
           status_code, content_type,  
           request_headers_json, request_body_bytes,  
           response_headers_json, response_body_bytes,  
           request_size, response_size, duration_ms, is_complete, error)  
withself._buffer_lock:  
self._db_buffer.append(row)  
  
asyncdefstart_flush_loop(self):  
"""每 3 秒批量写入一次"""  
whileTrue:  
await asyncio.sleep(3)  
awaitself.flush_buffer()
```

- • Body 限制 1MB（超过截断），防止大文件撑爆数据库
- • 图片响应 base64 编码后存储，前端可直接展示
- • 停止会话时强制 flush，保证数据完整性

- ![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_005_1e09fdd66a15f710.png)

---

## 四、设备代理配置——一键无感

### 4.1 Android 设备

Android 设备代理配置通过 ADB 命令完成，分为真机和模拟器两种场景：

```
asyncdefsetup_device_proxy(device_type, device_id, proxy_port):  
    host_ip = _get_local_ip()  
  
if device_type == "adb":  
        is_emulator = await _detect_emulator(device_id)  

# 关键：模拟器使用 10.0.2.2（指向宿主机），真机使用局域网 IP  

        proxy_host = "10.0.2.2"if is_emulator else host_ip  
  
await adb_shell(device_id,  
"settings", "put", "global", "http_proxy", f"{proxy_host}:{proxy_port}")
```

**模拟器检测逻辑：**

```
asyncdef_detect_emulator(device_id):  

# 方法 1：查询 ro.kernel.qemu 属性  

    out = await adb_shell(device_id, "getprop", "ro.kernel.qemu")  
if out.strip() == "1":  
returnTrue  

# 方法 2：设备 ID 以 emulator- 开头  

return device_id.startswith("emulator-")
```

为什么模拟器要用  `10.0.2.2`  ？因为 Android 模拟器的网络是虚拟化的，  `localhost`  指向模拟器自身而非宿主机。  `10.0.2.2`  是 Android 模拟器中指向宿主机的特殊地址。

### 4.2 HarmonyOS 设备

HarmonyOS 使用 HDC (HiSilicon Device Connect) 命令，代理配置方式与 Android 类似：

```
elif device_type == "hdc":  
await hdc_shell(device_id,  
"settings", "put", "global", "http_proxy", f"{host_ip}:{proxy_port}")
```

### 4.3 iOS 设备

iOS 无法通过命令行设置代理，因此返回手动配置指引：

```
else:  
return {  
"manual": True,  
"instructions": [  
f"1. 打开设置 > Wi-Fi > 当前网络 > HTTP 代理 > 手动",  
f"2. 服务器: {host_ip}",  
f"3. 端口: {proxy_port}",  
        ],  
    }
```

### 4.4 代理移除

测试结束后需要清理代理设置，否则设备断网：

```
asyncdefteardown_device_proxy(device_type, device_id):  
if device_type == "adb":  

# 设置为 :0 表示清除代理  

await adb_shell(device_id, "settings", "put", "global", "http_proxy", ":0")
```

---

## 五、CA 证书管理

### 5.1 证书生成

mitmproxy 首次启动时会自动在  `~/.mitmproxy/`  下生成 CA 证书。我们不做额外的证书管理，直接复用 mitmproxy 的证书体系。

### 5.2 证书安装到 Android 设备

```
asyncdefinstall_cert_to_device(device_type, device_id):  
    cert_path = "~/.mitmproxy/mitmproxy-ca-cert.pem"  
  
if device_type == "adb":  

# 1. Push 证书到设备  

await adb("push", cert_path, "/sdcard/mitmproxy-ca-cert.pem")  
  

# 2. 触发系统证书安装 Activity  

await adb_shell(device_id,  
"am", "start",  
"-a", "android.credentials.INSTALL",  
"-t", "application/x-x509-ca-cert",  
"-d", "file:///sdcard/mitmproxy-ca-cert.pem")
```

用户只需在手机弹出的安装确认界面点击"确定"即可。

### 5.3 证书安装到 iOS 设备

iOS 需要通过 Safari 访问证书下载链接：

```
else:  
return {  
"instructions": [  
f"1. Safari 打开: http://{host_ip}:8910/api/proxy/cert/download",  
"2. 安装描述文件",  
"3. 设置 > 通用 > 关于本机 > 证书信任设置 > 启用完全信任",  
        ],  
    }
```

后端提供证书下载接口  `/api/proxy/cert/download`  ，直接返回 PEM 文件。

---

## 六、SSL Pinning Bypass（可选高级功能）

### 6.1 什么时候需要

**大多数 App 只要正确安装 CA 证书就能正常抓包。**  只有少数安全要求较高的 App（银行类、支付类、部分大厂 App）做了 Certificate Pinning，才需要额外的 Bypass 操作。

判断是否需要 Bypass 很简单：如果代理已启动、证书已安装，但 App 请求全部失败（SSL handshake error），那就是遇到了 Pinning。

### 6.2 实现方式

AutoPilot 提供了基于 Frida 的 SSL Pinning Bypass 作为  **可选功能**  。Frida 是延迟导入的——如果用户未安装  `frida`  包，该功能不可用但不影响其他抓包能力。

```
asyncdefstart_ssl_bypass(device_id: str, package: str):  
try:  
import frida  # 延迟导入，未安装时优雅降级  

except ImportError:  
return {"ok": False, "error": "frida not installed. Run: pip install frida-tools"}  
  
    device = frida.get_device_matching(lambda d: d.id == device_id, timeout=5)  
    pid = device.spawn([package])     # Spawn 模式：App 启动前注入  

    session = device.attach(pid)  
  
    script = session.create_script(bypass_script_source)  
    script.load()  
    device.resume(pid)
```

Bypass 脚本覆盖 8 种主流 Pinning 实现，每个 Hook 独立 try-catch，互不影响。

### 6.3 前置条件与限制

使用 Frida Bypass 需要：

- • Android 设备已 root（或使用 Magisk）
- • 设备上已部署 frida-server（平台提供状态检查和一键启动）
- • 安装了
  `frida`
  Python 包

**实际工作中的使用频率较低**  ——在我们的日常测试场景中，绝大部分内部 App 和第三方 App 在安装 CA 证书后即可正常抓包，只有极少数情况需要启用 Bypass。平台将其作为"遇到再用"的备选能力保留。

---

## 七、请求篡改引擎——TamperEngine

### 7.1 设计理念

传统的 Mock 方案（Charles Map Local、mitmproxy 脚本）需要开发者写代码或配置文件。我们的目标是  **让测试工程师通过 GUI 配置规则，即可实现常见的篡改场景**  。

TamperEngine 支持两大类篡改：

1. 1.
   **数据篡改**
   （修改 JSON 响应体中的字段值）
2. 2.
   **网络故障模拟**
   （延迟、超时、断连、限速）

### 7.2 规则匹配

每条规则有三个匹配维度，使用  `fnmatch`  通配符：

```
def_match_rule(self, rule, host, path, method) -> bool:  
    match_host = rule.get("match_host", "*").lower()   # e.g., "*.api.example.com"  

    match_path = rule.get("match_path", "*")           # e.g., "/api/v1/user*"  

    match_method = rule.get("match_method", "*").upper()  # e.g., "GET"  

  
if match_host != "*"andnot fnmatch(host, match_host):  
returnFalse  
if match_path != "*"andnot fnmatch(path, match_path):  
returnFalse  
if match_method != "*"and match_method != method:  
returnFalse  
returnTrue
```

### 7.3 数据篡改策略

支持 6 种数据篡改策略：

![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_006_3d467431840cdb09.png)

| 策略 | 效果 | 测试场景 |
| --- | --- | --- |
| `set_null` | 字段置为 null | 空值容错 |
| `set_empty` | 智能置空（字符串→“”，数组→[]，数字→0） | 空数据展示 |
| `type_error` | 类型强转（string/number/boolean/array/object/null） | 类型异常容错 |
| `remove_field` | 删除字段 | 缺失字段容错 |
| `boundary` | 填充超长值（默认 10000 个 A） | 边界值 UI 展示 |
| `custom` | 自定义任意值 | 特定场景模拟 |
| `mock_response` | 整体替换响应体 | 完全自定义接口返回 |

**字段定位——支持嵌套路径：**

```
def_get_nested_field(self, obj, field_path):  
"""支持 'data.user.name' 或 'data.items.0.title' 的点分路径"""  
    parts = field_path.split(".")  
    current = obj  
for part in parts:  
ifisinstance(current, dict) and part in current:  
            current = current[part]  
elifisinstance(current, list):  
            idx = int(part)  
            current = current[idx]  
return current
```

**随机字段选择模式：**

手动指定字段路径适合明确的测试场景。但有时我们想做"随机字段置空"来发现意料之外的容错问题。TamperEngine 支持  **随机选择字段**  ：

```
def_resolve_fields(self, body, params):  
    field_mode = params.get("field_mode", "manual")  
  
if field_mode == "random":  
        random_count = params.get("random_count", 1)    # 随机几个字段  

        random_depth = params.get("random_depth", 1)    # 搜索深度  

        random_scope = params.get("random_scope", "")   # 限定范围  

  

# 收集所有可篡改的叶子路径  

        all_paths = self._collect_leaf_paths(target_obj, max_depth=random_depth)  

# 随机采样  

        chosen = random.sample(all_paths, min(random_count, len(all_paths)))  
return chosen  
else:  
return params.get("fields", [])
```

`_collect_leaf_paths`  递归遍历 JSON 对象，收集所有可修改的叶子节点路径，支持深度控制避免过深递归。

### 7.4 网络故障模拟

6 种网络异常策略：

```
NETWORK_FAULT_STRATEGIES = {"delay", "timeout", "error_status", "disconnect", "throttle", "random_fault"}  
  
def_execute_fault(self, flow, strategy, params):  
if strategy == "delay":  

# 固定延迟 + 随机抖动  

        delay_ms = params.get("delay_ms", 2000)  
        jitter_ms = params.get("jitter_ms", 0)  
        actual = delay_ms + random.randint(-jitter_ms, jitter_ms)  
        time.sleep(actual / 1000.0)  
return {"fault": "delay", "delay_ms": actual}  
  
elif strategy == "timeout":  

# 等待后直接 kill 连接  

        time.sleep(params.get("timeout_ms", 5000) / 1000.0)  
        flow.kill()  
return {"fault": "timeout"}  
  
elif strategy == "disconnect":  

# 立即断开  

        flow.kill()  
return {"fault": "disconnect"}  
  
elif strategy == "error_status":  

# 返回指定错误状态码的 Mock 响应  

from mitmproxy.http import Response  
        status_code = int(params.get("status_code", 500))  
        flow.response = Response.make(  
            status_code,  
f'{{"error": "simulated {status_code}"}}'.encode(),  
            {"Content-Type": "application/json"},  
        )  
return {"fault": "error_status", "status_code": status_code}  
  
elif strategy == "throttle":  

# 限速：记录到 flow metadata，在 response 阶段按 body 大小 sleep  

        rate_kbps = params.get("rate_kbps", 50)  
        flow.metadata["throttle_rate_kbps"] = rate_kbps  
return {"fault": "throttle", "rate_kbps": rate_kbps}
```

**限速实现的巧妙之处：**  `throttle`  策略在 request 阶段只是标记，真正的 sleep 发生在 response 阶段：

```

# FlowCaptureAddon.response() 中  

throttle_rate = flow.metadata.get("throttle_rate_kbps")  
if throttle_rate and flow.response:  
    body_len = len(flow.response.raw_content orb"")  

# 按照 body 大小和限速值计算 sleep 时间  

    sleep_sec = body_len / (throttle_rate * 1024 / 8)  
    time.sleep(min(sleep_sec, 30))  # 上限 30 秒，防止极端情况

```

这样更真实地模拟了慢网络——请求正常发送，响应"慢慢到达"。

**随机故障模式：**  混沌测试的利器：

```
def_apply_random_fault(self, flow, params):  

# 按概率触发（默认 30%）  

    fault_rate = params.get("fault_rate", 30)  
if random.randint(1, 100) > fault_rate:  
returnNone  
  

# 从故障池中随机选一个  

    faults = params.get("faults", ["delay", "error_status", "disconnect"])  
    chosen = random.choice(faults)  
returnself._execute_fault(flow, chosen, fault_params)
```

配置  `random_fault`  规则后，匹配的请求会以 30% 的概率随机遭遇延迟、错误码或断连中的一种。非常适合发现 App 在不确定网络环境下的容错问题。

### 7.5 篡改执行时机

数据篡改和网络故障的执行时机不同：

![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_007_205d0146f44da064.png)

### 7.6 篡改 Diff 记录

每次篡改都会记录原始值和篡改后的值，前端展示 Diff 对比：

```
defapply_to_response(self, flow):  
    original_body = copy.deepcopy(body)  
  

# ... 执行篡改 ...  

  
return {  
"original": json.dumps(original_body, ensure_ascii=False, indent=2),  
"tampered": json.dumps(body, ensure_ascii=False, indent=2),  
    }
```

前端用双栏视图展示 before/after，测试工程师可以直观看到每条请求被修改了什么。

![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_008_b0a4445d90d5b6e0.png)

---

## 八、实时通信方案

### 8.1 WebSocket 实时 Flow 推送

前端通过 WebSocket 连接获取实时流量数据：

```
// useProxyWs.js  
const ws = newWebSocket(`ws://127.0.0.1:8910/api/proxy/ws/${sessionId}`)  
  
ws.onmessage = (event) => {  
const { event: eventType, flow } = JSON.parse(event.data)  
if (eventType === "flow") {  
updateFlowList(flow)  
    }  
}
```

后端广播逻辑：

```
asyncdefbroadcast(self, event, data):  
    msg = json.dumps({"event": event, "flow": data})  
    dead = set()  
for ws inself.ws_clients:  
try:  
await ws.send_text(msg)  
except Exception:  
            dead.add(ws)  
self.ws_clients -= dead  # 自动清理断开的客户端

```

### 8.2 Flow 序列化分层

为了平衡实时性和数据完整性，序列化分两层：

- •
  **轻量序列化**
  （
  `_serialize_flow`
  ）：用于列表展示和 WebSocket 推送，只包含基本信息（method, host, path, status, size, duration）
- •
  **完整序列化**
  （
  `_serialize_flow_full`
  ）：用于详情查看，包含完整 headers 和 body

```
def_serialize_flow(flow):  
"""轻量版：列表展示用"""  
return {  
"id": str(id(f)),  
"method": req.method,  
"host": req.pretty_host,  
"path": req.path,  
"status_code": resp.status_code if resp elseNone,  
"content_type": ct.split(";")[0].strip(),  
"response_size": len(resp.raw_content),  
"duration_ms": round((resp.timestamp_end - f.timestamp_start) * 1000, 1),  
    }  
  
def_serialize_flow_full(flow):  
"""完整版：详情面板用"""  
    result = _serialize_flow(f)  
    result["request_headers"] = dict(req.headers)  
    result["request_body"] = body.decode("utf-8", errors="replace")  
    result["response_headers"] = dict(resp.headers)  

# 图片 body 做 base64 编码  

if ct.startswith("image/"):  
        result["response_body"] = base64.b64encode(body).decode("ascii")  
        result["response_body_type"] = "image"  
else:  
        result["response_body"] = body.decode("utf-8", errors="replace")  
return result
```

---

## 九、典型使用场景

### 场景 1：接口容错测试

> 验证 App 在接口返回异常数据时的表现。

配置篡改规则：

- • Host:
  `*.api.myapp.com`
- • Path:
  `/api/v1/user/profile`
- • 策略:
  `set_null`
- • 字段:
  `data.avatar_url`
  ,
  `data.nickname`

效果：用户头像和昵称字段返回 null，验证 App 是否显示默认头像和"未设置昵称"。

### 场景 2：弱网环境测试

> 验证 App 在弱网环境下的用户体验。

配置网络故障规则：

- • Host:
  `*`
- • 策略:
  `delay`
- • delay_ms: 3000, jitter_ms: 1000

效果：所有请求随机延迟 2-4 秒，验证 App 的 loading 状态、超时提示、重试机制。

### 场景 3：混沌测试

> 发现 App 在不确定网络环境下的未知问题。

配置随机故障规则：

- • Host:
  `*.api.myapp.com`
- • 策略:
  `random_fault`
- • fault_rate: 20%
- • faults: [“delay”, “error_status”, “disconnect”]

效果：20% 的请求会随机遭遇延迟、500 错误或断连。跑一轮自动化用例，看哪些页面会崩溃。

### 场景 4：边界值 UI 测试

> 验证 App 在极端数据下的 UI 展示。

配置篡改规则：

- • 策略:
  `boundary`
- • 字段模式:
  `random`
- • random_count: 3
- • random_depth: 2

效果：随机选 3 个字段填充 10000 个字符的超长值，验证 UI 是否溢出、截断处理是否正确。

---

## 十、工程总结

### 关键技术决策

| 决策 | 原因 |
| --- | --- |
| 基于 mitmproxy 而非自研代理 | 成熟的 HTTPS 解密方案，丰富的 addon 机制 |
| 代理运行在独立线程 | 不阻塞 FastAPI 主事件循环 |
| 队列 + 批量 drain 的跨线程通信 | 平衡实时性与线程安全 |
| Frida 作为可选依赖延迟导入 | 绝大部分场景不需要，未安装时不影响核心功能 |
| fnmatch 通配符匹配规则 | 简单直觉，覆盖大部分场景 |
| 篡改 Diff 完整记录 | 测试可追溯，结果可复现 |
| SQLite 持久化 + 3 秒批量写入 | 平衡 I/O 性能与数据可靠性 |

### 与传统方案对比

| 维度 | Charles/mitmproxy CLI | AutoPilot 抓包模块 |
| --- | --- | --- |
| 代理配置 | 手动设置 Wi-Fi 代理 | 一键配置（Android/HarmonyOS） |
| 证书安装 | 手动下载、安装、信任 | 一键推送 + 触发安装 |
| SSL Bypass | 手动启动 Frida + 运行脚本 | 一键注入（可选，多数场景不需要） |
| 请求篡改 | 写 Python 脚本 / Map Local | GUI 规则配置，支持 12 种策略 |
| 数据记录 | 看完就没了 / 手动保存 | 自动持久化到 SQLite，支持导出 HAR |
| 与测试联动 | 无 | 可在 UI 自动化执行期间同步抓包 |

### 已知限制

1. 1.
   **iOS 代理配置仍需手动**
   ：Apple 不提供命令行设置代理的 API
2. 2.
   **SSL Pinning Bypass 需要 root**
   ：Frida 注入需要设备 root，且部分 App 有 Frida 检测机制——但实际使用中极少遇到需要 Bypass 的场景
3. 3.
   **大文件响应截断**
   ：Body 超过 1MB 只存储前 1MB，避免数据库膨胀

---

## 十一、后记

移动端 HTTPS 抓包本质上是在"安全"和"可调试性"之间找到平衡。App 通过 SSL Pinning 保护通信安全，我们通过 Frida 动态注入绕过它——这是测试工程师和安全机制之间永恒的博弈。

AutoPilot 的抓包模块并没有发明新技术（mitmproxy、Frida 都是成熟的开源工具），它的价值在于  **将这些工具的使用门槛从"会写脚本"降低到"点几个按钮"**  。这也是整个 AutoPilot 平台的核心理念：不是替代工具，而是让工具更容易被使用。

预览时标签不可点
![]()

微信扫一扫   
 关注该公众号

继续滑动看下一个
轻触阅读原文
![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_010_b585214916937a92.png)
测试加
向上滑动看下一个

[知道了](javascript:;)

![]()
微信扫一扫
  
使用小程序
[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

×

分析

![]()
![](20260602_AutoPilot：网络抓包与Mock：移动端HTTPS流量捕获的工程实践_assets/img_013_b585214916937a92.png)

微信扫一扫可打开此内容，   
 使用完整服务

：
，
，
，
，
，
，
，
，
，
，
，
，
。
视频
小程序
赞
，轻点两下取消赞
在看
，轻点两下取消在看
分享
留言
收藏
听过