# Agent 提示词工程：移动端 UI 测试的 Prompt 设计实践

![](20260606_Agent提示词工程：移动端UI测试的Prompt设计实践_assets/img_001_601edfca39a484f5.jpg)

# Agent 提示词工程：移动端 UI 测试的 Prompt 设计实践

xinxi
xinxi
[测试加](javascript:void(0);)

![]()
在小说阅读器读本章
去阅读
![]()
在小说阅读器中沉浸阅读

# Agent 提示词工程：移动端 UI 测试的 Prompt 设计实践

> 框架选好了、模式定了，接下来是最「玄学」也最关键的环节——怎么让模型稳定输出你想要的动作。

---

## 一、Prompt 是 Agent 的「行为准则」

前两篇分别聊了「什么时候用 AI 代替传统」和「Agent 框架怎么选」。但不管你用什么框架、选什么模式，最后都会撞上同一堵墙：

**同一个任务，同一套代码，GPT-4o 能跑通，换成 DeepSeek 就翻车。**

这不是模型能力的问题，而是 Prompt 没适配。

Agent 的 Prompt 和普通 Chat 的 Prompt 有本质区别：

|  | Chat Prompt | Agent Prompt |
| --- | --- | --- |
| 目标 | 生成一段好文本 | 输出一个可执行的动作 |
| 容错率 | 高，措辞差点无所谓 | 极低，格式错一个字符就挂了 |
| 上下文 | 一问一答，短的 | 持续积累，可能 20 轮 |
| 模型差异 | 不明显 | 同一 Prompt，不同模型天差地别 |

这篇文章就从实际踩过的坑出发，拆解移动端 UI 测试 Agent 的 Prompt 该怎么设计。

---

## 二、系统提示词：给 Agent 建立「世界观」

系统提示词（System Prompt）是 Agent 行为的基础约束。移动端 UI 测试 Agent 的系统提示词需要覆盖至少三层信息：

### 2.1 操作空间定义

首先要告诉模型：你能做什么、怎么描述你的操作。

```

## 可用动作- do(action="Launch", app="微信")          # 启动应用- do(action="Tap", element=[523, 847])     # 点击，坐标 0-1000 归一化- do(action="Type", text="你好")            # 输入文本- do(action="Swipe", start=[x1,y1], end=[x2,y2])  # 滑动- do(action="Back")                        # 返回- do(action="Home")                        # 回到桌面- do(action="Wait", duration="3 seconds")  # 等待- do(action="Long Press", element=[x,y])   # 长按- finish(message="任务完成描述")            # 结束## 坐标说明坐标使用归一化 0-1000 空间，不是像素值。例如屏幕正中间是 element=[500, 500]。

```

**设计要点：**

- •
  **动作名大小写不敏感**
  。模型可能输出
  `tap`
  、
  `Tap`
  、
  `TAP`
  ，解析层统一处理。不要靠 Prompt 约束大小写——靠代码容错。
- •
  **坐标归一化**
  。设备分辨率千差万别（1080×2400、1440×3200…），让模型统一用 0-1000 空间输出，执行时换算。这个约定需要在 Prompt 里明确说明，否则模型会倾向于给像素值。
- •
  **finish 的语义要严格**
  。很多模型倾向于「多做一步」——完成了任务还要再加一个「截图确认」。需要在 Prompt 里反复强调：
  `finish()`
  意味着彻底结束，禁止再有任何操作。

### 2.2 行为规则

动作定义只是提供了「词汇表」。真正的难点是告诉模型「在什么情况下做什么」。

这是 AutoPilot 系统提示词中的规则片段（Android 端，中英双语各一套）：

```

## 重要规则1. 每次只执行一个动作，不要尝试一次输出多个 do()2. 操作前先检查当前 App 是否正确，不对就先切到目标 App3. 如果进入错误的页面，先用 Back 返回4. 连续 Wait 最多 3 次，超过说明出问题了，用 finish() 结束5. 完成所有步骤后立刻 finish()，禁止做任何额外操作6. 不要自己添加用户没要求的步骤7. 遇到弹窗/权限请求先处理，再继续主任务

```

这些规则不是一拍脑袋列出来的。每一条背后都有翻车案例：

| 规则 | 如果不写会怎样 |
| --- | --- |
| 每次一个 do() | 模型一次输出 5 个操作，但只执行了第一个，后面的全丢了 |
| 检查 App | 任务要操作微信，但当前在桌面，模型直接对着桌面找微信按钮 |
| 错误页面 Back | 点到广告进了 H5，模型继续在 H5 里找原生页面的元素 |
| Wait 上限 | 网络慢加载中，模型连续 Wait 了 20 次，token 烧光 |
| 禁止额外操作 | 任务完成了，模型「好心地」加一步截图确认，结果截到了弹窗 |
| 不擅自加步骤 | 模型觉得「用户可能还想检查一下」，自己补了 3 步多余的 |

### 2.3 输出格式约束

这是最不「智能」但最关键的部分。模型输出的不是给人看的，是给解析器吃的。

AutoPilot 的格式约定：

```

## 回复格式你必须严格按以下格式回复：<think>你的思考过程</think><answer>do(action="Tap", element=[500, 500])</answer>第一步：在 <think> 标签中描述你的分析和判断第二步：在 <answer> 标签中给出具体操作

```

> *注：上述  `<think>`  和  `<answer>`  是自定义的 XML 标签，不是标准 HTML。实际发送给模型时是纯文本；发布到微信等平台时需转义为  `&lt;think&gt;`  避免被吃掉。*

为什么用  `<think>`  +  `<answer>`  而不是直接让模型输出 JSON？

- •
  **思考过程可见**
  。调试时可以看到模型「为什么」做出这个决定。这对排查误操作至关重要。
- •
  **流式解析友好**
  。当检测到
  `<answer>do(action=`
  时，解析器立即切换状态开始捕获动作，之前的思考文本已经呈现给用户了。
- •
  **容错性好**
  。JSON 嵌套引号、花括号匹配容易出问题，
  `do()`
  这种函数调用式文本解析更宽容。

---

## 三、「严格模式」vs「自由模式」：两套 Prompt 策略

同一个 Agent，不同场景需要不同的行为约束强度。

### 3.1 自由模式：给模型空间

适合探索性测试、一次性任务。Prompt 简短、约束少：

```
重要规则：1. 除非任务真正完成，否则不要用 finish()2. 每次只执行一个操作3. 完成后立刻 finish()，不要做额外操作
```

模型可以自行判断步骤顺序、自行决定是否需要等待。

### 3.2 严格模式：把模型「绑在轨道上」

适合回归测试——已有明确的步骤列表，需要 Agent 按顺序执行、不能跳不能漏。

```
强约束模式：- 必须严格按用户指令中列出的步骤顺序执行- 当前是第 {step_idx}/{total_steps} 步：{step_description}- 你只能执行当前这一步，完成后立刻输出下一步- 禁止跳过步骤、禁止合并步骤、禁止调整步骤顺序- 禁止根据当前页面状态「优化」步骤
```

运行时在每条 user message 中注入当前步骤索引和描述，让模型始终知道「我现在在哪一步」。

### 3.3 为什么只靠 Prompt 还不够

严格模式下，模型仍然可能「跑偏」。AutoPilot 在 iOS 端遇到的情况尤其严重——模型倾向于忽略 Prompt 中的步骤约束，自行发挥。

iOS 端额外加了  **强制动作纠正**  ：

```

# iOS agent: 如果模型输出 Tap 但当前步骤要求 Killif"kill"in current_step.lower() and action.action_type != "Kill":# 强制覆盖模型输出    action = Action(action_type="Kill", app=extract_app_name(current_step))

```

这个逻辑很粗暴，但很有效。  **能用代码兜底的地方，不要寄希望于更精准的 Prompt。**  Prompt 是概率性的，代码是确定性的。

---

## 四、动作解析：从文本到可执行操作

Prompt 设计好了，模型按照约定输出了  `do(action="Tap", element=[523, 847])`  。接下来怎么把它变成真实的屏幕点击？

这个环节是  **整个 Prompt 工程中最容易翻车的地方**  。模型的输出永远不是 100% 符合约定的。

### 4.1 为什么要自定义格式而不是 Function Calling

|  | Function Calling | 自定义 do()/finish() |
| --- | --- | --- |
| 供应商绑定 | 各厂商格式不完全兼容 | 任何模型都能用 |
| 容错能力 | JSON 解析失败即报废 | 多层降级解析 |
| 流式处理 | 必须等完整 JSON | 检测到 `do(action=` 即截断 |
| 调试可读性 | 嵌套 JSON，人眼不友好 | 一行文本，一目了然 |

一个实际场景：模型输出  `do(action="Type", text="你好，今天天气不错")`  。这段文本里的逗号如果被 JSON 解析器当成分隔符，就会出错。但  `do()`  格式用正则匹配就没事。

### 4.2 多层降级解析

```
defparse_action(content: str) -> Action | None:# 第 1 层：尝试 AST 解析（最安全）# 将 do(...) 作为 Python 函数调用解析try:        tree = ast.parse(content.strip(), mode='eval')return extract_action_from_ast(tree)except SyntaxError:pass# 第 2 层：正则匹配（兜底）# 容忍小格式错误：多余空格、少了逗号等match = re.search(r'do\(action="(\w+)"(?:,\s*(.+))?\)', content)ifmatch:return extract_action_from_regex(match)# 第 3 层：让模型重试returnNone# 调用方会带上错误提示，让模型重新输出

```

每层解析失败后降级到下一层，三层都失败才触发模型重试。实测中，大约 85% 的模型输出在第一层（AST）就能通过，10% 在第二层（正则）通过，剩余 5% 触发重试后基本都能修正。

### 4.3 不要「纠正」模型输出

一个反直觉的经验：  **解析层的职责是理解模型意图，不是纠正模型错误。**

比如模型输出  `do(action="click", element=[500, 500])`  ——应该自动映射  `click`  →  `Tap`  ，而不是丢掉重试。但模型输出  `do(action="Tap", element=[1500, -200])`  ——不应该自动 clamp 坐标，应该让模型重试。因为坐标越界说明模型理解有偏差，不是一个格式错误。

---

## 五、模型差异：同一个 Prompt，不同模型表现差异巨大

这是 Prompt 工程里最「痛」的经验：  **没有通用 Prompt。**

### 5.1 不同模型的「性格」差异

| 模型 | 特点 | 对 Prompt 的影响 |
| --- | --- | --- |
| GPT-4o | 理解力强，遵循规则好 | 简洁 Prompt 即可，规则少一点 |
| GLM-4V | 中文友好，但容易「多做事」 | 需要强调「不要额外操作」 |
| Qwen-VL | 速度快，但坐标有时偏差大 | 需要更精确的空间描述 |
| DeepSeek | 推理能力强，但偶尔格式不稳定 | 需要更严格的动作格式约束 |
| 豆包 Vision | 中文场景好，但模型行为变化快 | 需要频繁微调 Prompt |

这些是项目中的经验观察，不是系统评测——不同项目、不同任务类型可能有完全不同的结论。

### 5.2 iOS 端 vs Android 端

同一套 Prompt 逻辑，iOS 和 Android 差异明显：

- •
  **Android**
  ：模型通常遵循步骤约束，偏差较少。
- •
  **iOS**
  ：模型更容易「自行发挥」——可能是 iOS 截图风格不同、控件视觉特征不同，或训练数据分布的差异。

所以 iOS 端多了  **显式的步骤-动作映射**  ：

```
⚠️ 步骤关键词与动作映射（必须严格遵守）：- 步骤含"杀死/结束/强制停止" → 必须用 do(action="Kill", app="xxx")- 步骤含"启动/打开" → 必须用 do(action="Launch", app="xxx")- 步骤含"点击" → 必须用 do(action="Tap", element=[x,y])- 步骤含"输入" → 必须用 do(action="Type", text="xxx")
```

Android 端不需要这段——加进去反而让模型困惑。  **不同端的 Prompt 要分开维护，共享的只有核心逻辑。**

### 5.3 模型版本迁移

大模型 API 更新频繁，新版本的行为可能和旧版本完全不同。一个实际经验：

- • GLM 某个版本更新后，
  `finish()`
  输出的频率大幅增加——模型变「懒」了，遇到稍微不确定的情况就直接 finish
- • 解决方法：在 Prompt 里加了「如果没有把握，宁可多尝试一次也不要提前 finish」

**给 Prompt 版本打上备注**  ：标注每条规则是什么时候加的、为什么加的、对应哪个模型版本。否则三个月后谁都不记得那条看起来奇怪的限制是干嘛用的。

---

## 六、上下文管理：别让模型「失忆」

Agent 执行 10 步任务就产生了 10 轮对话、10 张截图。不加管理的话，token 消耗线性增长，而且模型会在中间步时「忘记」最初的任务指令。

### 6.1 锚点 + 滑动窗口

```
上下文 = [System Prompt]          ← 永久保留        + [首轮用户消息]           ← 永久保留（「锚点」，固定任务目标）        + [首轮助手回复]           ← 永久保留（初始理解）        + [最近 N 轮对话]          ← 滑动窗口
```

**首轮对话是锚点**  ——它包含了用户最初的任务描述。如果这条被移除了，模型执行到第 15 步时已经不知道自己在干什么。

### 6.2 历史截图移除

每步执行后，历史消息中的截图全部移除，只保留文本：

```

# 去掉旧截图，防止 context 爆炸for msg inself._context:if msg.get("role") == "user"andisinstance(msg.get("content"), list):        msg["content"] = [            part for part in msg["content"]if part.get("type") != "image_url"        ]

```

这在 XML 内核模式下尤其重要——XML 模式不需要截图，但 Vision 模式也需要剥离旧截图，只保留当前帧。

### 6.3 压缩的边界

有些信息是  **不能压缩的**  ：

- • 任务目标 → 锚点保留
- • 上一步做了什么 → 滑动窗口文本保留
- • 当前页面状态 → 当前截图，不可移除

可以压缩的：

- • 之前每一步的截图 → 移除
- • 之前的思考过程 → 保留但可以精简

---

## 七、断言提示词：独立的「裁判」

测试的本质不是操作，是  **验证操作结果**  。如果让执行操作的模型同时做断言，就是「自己批改自己的试卷」。

### 7.1 独立的断言模型和 Prompt

AutoPilot 的做法：执行完成后，用  **不同的模型**  、  **不同的 Prompt**  进行验证。

执行模型的 Prompt 是「操作指南」——十几条规则、动作描述。断言模型的 Prompt 只有四句话：

```
你是一个严格的 UI 截图断言验证器。用户会给你一张手机截图和一条断言描述，你需要判断截图是否满足断言。你必须严格按以下 JSON 格式输出，不要输出任何其他内容：{"result": true, "reason": "一句话理由"}result 只能是 true 或 false，不允许其他值。
```

为什么这么短？

- • 断言任务本身简单（「这张图里有没有 XYZ」），不需要复杂指令
- • Prompt 越短，模型越不容易「过度解读」
- • 严格约束输出格式（只允许
  `true`
  /
  `false`
  ），避免模型加戏

### 7.2 断言的容错解析

即使 Prompt 约束死了 JSON 格式，模型仍然可能输出各种变体。解析层做了 4 层兼容：

```

# 第 1 层：直接 JSON 解析try: return json.loads(content)# 第 2 层：正则提取 JSON 块match = re.search(r'\{.*"result".*\}', content)# 第 3 层：中文关键词匹配（先检查否定，再检查肯定）if"不满足"in content: returnFalseif"满足"in content: returnTrue# 第 4 层：英文关键词匹配if"false"in content.lower(): returnFalseif"true"in content.lower(): returnTrue

```

真实经验：  **给断言 Prompt 做容错解析的投入产出比，比优化断言 Prompt 本身更高。**  模型偶尔输出不符合约定的格式是必然的，与其指望更精准的 Prompt 消除这种必然性，不如让解析层能消化它。

---

## 八、提示词预处理：能用规则就不用模型

这是最容易被忽视但 ROI 最高的一环：  **在执行前，先用正则匹配过滤掉不需要模型参与的任务。**

![](20260606_Agent提示词工程：移动端UI测试的Prompt设计实践_assets/img_004_b389304719b498c2.png)

**AutoPilot 的 TaskPreprocessor 用正则检测以下模式：**

```
PATTERNS = {"launch_app":  r"(打开|启动|打开应用|启动应用|launch)\s*(.+)?","go_home":     r"(回到桌面|返回桌面|home|主屏幕)","go_back":     r"(返回上一页|返回|back)","screenshot":  r"(截图|截屏|screenshot)",}
```

这些操作不需要任何视觉理解——打开微信就是  `adb shell am start`  ，回到桌面就是  `adb shell input keyevent KEYCODE_HOME`  。用模型做这些事纯属浪费 token。

实测效果：约  **20% 的简单任务**  通过预处理器直接执行，跳过了 LLM 调用。这 20% 零成本、零延迟、结果确定。

---

## 九、不同任务类型的 Prompt 差异

前面讲的都是「逐步执行」的 Prompt——每一步发截图，模型返回一个 do()。但 AutoPilot 还有另外两种场景，它们的 Prompt 设计思路完全不同。

### 9.1 规划 Prompt：一次输出整个计划

Planning 模式不是让模型逐步思考，而是  **一次性生成完整的执行计划（JSON）**  。这和 ReAct 的 Prompt 是两种完全不同的设计：

```
ReAct Prompt（逐步）:  "你现在要做什么？"     → 模型返回一步操作Planning Prompt（全局）:  "任务是什么？给我完整计划"  → 模型返回整个 JSON 执行方案
```

Planning Prompt 的核心难点是  **让模型输出严格的 JSON**  ——这比输出  `do()`  函数调用格式难得多，因为 JSON 嵌套层级深、字段名必须精确。

AutoPilot 的 Planning Prompt 用了几个技巧：

**技巧 1：约束前置。**  在 Prompt 最前面就声明格式要求，不要放在末尾——模型对开头的关注度高于末尾。

```
[CRITICAL FORMAT RULES]1. 你的回复必须是且仅是一个合法 JSON 对象2. 不要输出自然语言解释3. 不要用 markdown 代码块4. 不要用 ```json``` 包裹5. 第一个字符必须是 {
```

**技巧 2：给完整的 JSON 结构示例。**  不是只描述格式，而是给出一个完整的输出示例：

```
{"task":"打开微信搜索张三并发送消息","app_name":"微信","steps":[{"step_id":1,"action_type":"LAUNCH","app_name":"微信"},{"step_id":2,"action_type":"TAP","element_selector":{"type":"text","value":"搜索"},"checkpoint":{"mode":"xml","text":"搜索框"}}]}
```

**技巧 3：关键字段单独特别提醒。**  模型在生成复杂 JSON 时，经常在某些字段上出错。比如  `app_name`  字段——模型有时候把整个任务描述填进去，而不是只填应用名。

```
[WARN] app_name 字段只能填写应用名称（如"微信"），不要填写完整任务描述！
```

这个提醒单独放在 Prompt 末尾，形成首尾双重约束。

### 9.2 编译 Prompt：从自然语言到结构化脚本

编译 Prompt 的任务是把测试用例的自然语言步骤转换为 JSON，再编译为 YAML 脚本。它和 Planning Prompt 的区别：

|  | Planning Prompt | Compiler Prompt |
| --- | --- | --- |
| 输出 | 可立即执行的计划 JSON | 可编译为脚本的结构化 JSON |
| 动作类型 | LAUNCH/TAP/SWIP/CHECKPOINT… | Type/Tap/Swipe + Target + Fallback |
| 目标定位 | 坐标或元素选择器 | 多层定位器（text/resource-id/vision） |
| 使用频率 | 每次执行都调用 | 编译一次，回放无限次 |

Compiler Prompt 里定义了 14 种动作类型，每种都需要  `target`  字段描述目标元素：

```
{"action":"Tap","target":{"description":"搜索按钮","xml_text":"搜索","resource_id":"com.example:id/search_btn","content_desc":"搜索图标"}}
```

**编译 Prompt 的关键设计：target 不是单一匹配条件，而是多层 fallback 的起点。**  脚本执行时，先用  `xml_text`  精确匹配，失败后试  `resource_id`  ，再失败试  `content_desc`  ，最后走 Vision 视觉定位。Prompt 需要引导模型输出尽可能多的定位信息，而不是只给一个坐标。

### 9.3 三种 Prompt 的设计哲学差异

```
逐步执行 Prompt:  "你是操作员，告诉我下一步做什么"规划 Prompt:      "你是项目经理，给我完整方案"编译 Prompt:      "你是脚本工程师，把步骤翻译成代码"
```

三者的共同点是都需要动作定义和格式约束，但关注点完全不同：

- • 执行 Prompt 关注
  **当前状态判断**
  （看截图，做决定）
- • 规划 Prompt 关注
  **全局步骤编排**
  （分解任务，安排顺序）
- • 编译 Prompt 关注
  **结构精确度**
  （字段完整、格式规范）

**不要试图用一套 Prompt 服务所有场景。**  这三种场景需要三套独立的系统提示词，各自维护、各自迭代。

---

## 十、Prompt 调试：出了问题怎么定位

Prompt 出问题时，表现形式通常不是「报错」，而是「行为不符合预期」——比如模型跳过了某一步、多做了操作、选错了元素。这种隐性问题很难定位。

### 10.1 日志三要素

每次模型调用，至少记录三件事：

```
[发送] system prompt hash + user message（截断截图）[接收] 完整的模型输出（含 <think>）[结果] 执行的动作 + 结果（成功/失败/偏离）
```

`<think>`  部分是调试金矿——它告诉你模型  **为什么**  做出这个决定。很多「模型犯傻」的案例，回头看  会发现模型的推理过程是合理的，只是对当前页面的理解有误。

### 10.2 调试流程

![](20260606_Agent提示词工程：移动端UI测试的Prompt设计实践_assets/img_005_683b18e88fca9b7c.png)

### 10.3 A/B 测试 Prompt 改动

改完 Prompt 不要只跑一次看效果。至少跑 20 个用例，对比改动前后的通过率。一个常见陷阱：加了一条规则后，解决了问题 A，但同时引入了问题 B。

```

# Prompt v2.3 改动测试# 改动：增加「遇到加载中先等 3 秒」规则# 测试结果：#   - 10 个慢网络用例通过率：60% → 90%  ✓ 解决了问题#   - 10 个快网络用例通过率：95% → 85%  ✗ 引入了新的等待超时# 结论：保留规则，但改为「遇到加载中等 2 秒」

```

---

## 十一、总结

| 环节 | 设计要点 | 踩过的坑 |
| --- | --- | --- |
| 系统提示词 | 动作定义 + 行为规则 + 输出格式三要素 | 规则太松模型乱来，太紧模型困惑 |
| 执行模式 | 自由模式给空间，严格模式绑轨道 | 严格模式只靠 Prompt 不够，需要代码兜底 |
| 动作格式 | do()/finish() 自定义约定 > Function Calling | AST 解析失败靠正则，再失败靠重试 |
| 模型适配 | 不同模型不同 Prompt，iOS/Android 分开 | 换模型不改 Prompt，同一个任务表现天差地别 |
| 上下文管理 | 锚点保留任务目标 + 滑动窗口 + 旧截图移除 | 不设锚点，第 15 步模型忘了最初要干啥 |
| 断言验证 | 独立模型 + 独立 Prompt + 多层格式容错 | 自己验证自己，准确率虚高 |
| 预处理 | 正则拦截简单命令，跳过 LLM | 约 20% 任务可以零成本执行 |
| 任务类型差异 | 执行/规划/编译三套 Prompt 各自独立 | 一套 Prompt 服务所有场景，效果都不好 |
| 调试方法 | 是金矿 + A/B 测试 20 用例以上 | 改了一条规则，解决了 A 问题引入了 B 问题 |

**核心经验：Prompt 工程的本质不是「写出完美的 Prompt」，而是建立一套让「不完美的 Prompt + 不完美的模型输出」仍然可用的容错体系。**  解析层的投入比 Prompt 优化的投入更有长期价值。

---

**相关文章：**

- •
  [AI 自动化 Agent 框架：移动端 UI 测试的架构设计与模式选择](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487401&idx=1&sn=fefde65550005642a3a2de19892e4f3d&scene=21#wechat_redirect)
- •
  [AutoPilot：AI 自动化 vs 传统自动化：移动端 UI 测试的两条路](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487393&idx=1&sn=272a981127a9f1573e1a53f45a5177c3&scene=21#wechat_redirect)
- •
  [AutoPilot：网络抓包与 Mock：移动端 HTTPS 流量捕获的工程实践](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487388&idx=1&sn=73945efa19c200175600384f0798fef1&scene=21#wechat_redirect)
- •
  [AutoPilot 性能监控：三端实时数据采集的设计与实现](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487377&idx=1&sn=48cee43cc13b698a69d956d94a5e2acf&scene=21#wechat_redirect)
- •
  [AutoPilot：AI 驱动的移动端自动化测试平台](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487366&idx=1&sn=8013e308cf2cb87cccbcb4227804fa09&scene=21#wechat_redirect)

预览时标签不可点
![]()

微信扫一扫   
 关注该公众号

继续滑动看下一个
轻触阅读原文
![](20260606_Agent提示词工程：移动端UI测试的Prompt设计实践_assets/img_007_b585214916937a92.png)
测试加
向上滑动看下一个

[知道了](javascript:;)

![]()
微信扫一扫
  
使用小程序
[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

×

分析

![]()
![](20260606_Agent提示词工程：移动端UI测试的Prompt设计实践_assets/img_010_b585214916937a92.png)

微信扫一扫可打开此内容，   
 使用完整服务

：
，
，
，
，
，
，
，
，
，
，
，
，
。
视频
小程序
赞
，轻点两下取消赞
在看
，轻点两下取消在看
分享
留言
收藏
听过