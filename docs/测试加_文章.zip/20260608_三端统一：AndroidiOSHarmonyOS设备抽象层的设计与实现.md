# 三端统一：Android / iOS / HarmonyOS 设备抽象层的设计与实现

![](20260608_三端统一：AndroidiOSHarmonyOS设备抽象层的设计与实现_assets/img_001_1ce1620850c5f3c7.jpg)

# 三端统一：Android / iOS / HarmonyOS 设备抽象层的设计与实现

原创
皓月
皓月
[测试加](javascript:void(0);)

![]()
在小说阅读器读本章
去阅读
![]()
在小说阅读器中沉浸阅读

# 三端统一：Android / iOS / HarmonyOS 设备抽象层的设计与实现

> Prompt 写好了，模型也输出了  `do(action="Tap", element=[500,500])`  。然后呢？谁来把这个归一化坐标变成真实的屏幕点击？

---

## 一、当 AI 输出 `Tap(500,500)` 之后

前三篇文章分别聊了「什么时候用 AI」「Agent 框架怎么选」「Prompt 怎么设计」。这三件事有一个共同的前提：  **模型只负责"想"，不负责"做"。**

模型输出  `do(action="Tap", element=[500, 500])`  之后，必须有人把这句话翻译成真实的设备操作。而这个"翻译"在三端完全是不同的语言：

```

# 同样一个"点击屏幕中央"，三端执行方式天差地别：# Android: 一条 adb shell 命令subprocess.run(["adb", "shell", "input", "tap", "540", "1200"])# HarmonyOS: 另一套完全不同的 shell 命令体系subprocess.run(["hdc", "shell", "uitest", "uiInput", "click", "540", "1200"])# iOS: 构造一个 W3C WebDriver Actions JSON，通过 HTTP POST 发给 WDArequests.post("http://localhost:8100/session/xxx/actions", json={"actions": [{"type": "pointer","id": "finger1","parameters": {"pointerType": "touch"},"actions": [            {"type": "pointerMove", "x": 180, "y": 400},   # 注意：这里不是 540 和 1200            {"type": "pointerDown", "button": 0},           # 因为要除以 SCALE_FACTOR            {"type": "pause", "duration": 100},            {"type": "pointerUp", "button": 0},        ]    }]})

```

如果不做抽象，上层 Agent 代码要为每个平台写一份。更糟的是，截图、文本输入、应用管理、获取当前 App——每一个操作在三端的实现都完全不同。

**设备抽象层的目标：让 ActionHandler 完全不知道底层是什么平台。**

这篇文章拆解 AutoPilot 设备层的真实设计和源码。

---

## 二、模块级接口约定：鸭子类型，不是 ABC

很多架构文章一上来就是抽象基类（ABC）。但在这个场景里，ABC 反而是负担。

AutoPilot 的做法是用  **模块级鸭子类型**  ：adb、hdc、xctest 三个包，各自暴露同名的模块级函数。目录结构就是架构：

![](20260608_三端统一：AndroidiOSHarmonyOS设备抽象层的设计与实现_assets/img_004_e4e6ce0a096bd8e7.png)

**为什么不用 ABC？**

| 方案 | 优点 | 移动端多平台场景的实际问题 |
| --- | --- | --- |
| ABC 抽象基类 | 类型安全，IDE 提示好 | iOS 的 `tap()` 需要 `wda_url` 参数，Android 不需要——强行统一签名会污染所有平台 |
| 模块级鸭子类型 | 灵活，各平台函数签名可以不同 | 没有编译期保证，但靠约定和 Code Review 足够 |

实际代码中，iOS 的函数签名确实和 Android/HarmonyOS 不同：

```

# Android / HarmonyOS: 只需要 device_iddeftap(x: int, y: int, device_id: str | None = None, delay: float | None = None):# iOS: 需要 wda_url 和 session_iddeftap(x: int, y: int, wda_url: str = "http://localhost:8100",        session_id: str | None = None, delay: float = 1.0):

```

**好的抽象不是"强行统一一切"，而是"统一该统一的，保留该保留的"。**

---

## 三、DeviceFactory：全局单例 + 懒加载的路由器

工厂本身的设计很简洁——核心就三个设计决策：

### 3.1 懒加载

```
classDeviceFactory:def__init__(self, device_type: DeviceType = DeviceType.ADB):self.device_type = device_typeself._module = None# 关键：初始化时不 import 任何平台模块    @propertydefmodule(self):ifself._module isNone:     # 第一次调用时才加载ifself.device_type == DeviceType.ADB:from . import adbself._module = adbelifself.device_type == DeviceType.HDC:from . import hdcself._module = hdcreturnself._moduledeftap(self, x, y, device_id=None, delay=None):returnself.module.tap(x, y, device_id, delay)

```

**好处：跑 Android 的进程永远不会 import  `hdc`  和  `xctest`  。**  三方依赖隔离——HDC 工具链的依赖不会污染 Android 环境，iOS 的  `requests`  库不会在纯 Android 场景下被加载。

### 3.2 全局单例

```
_device_factory: DeviceFactory | None = Nonedefset_device_type(device_type: DeviceType):global _device_factory    _device_factory = DeviceFactory(device_type)defget_device_factory() -> DeviceFactory:global _device_factoryif _device_factory isNone:        _device_factory = DeviceFactory(DeviceType.ADB)  # 默认 ADBreturn _device_factory

```

Agent 启动时调用一次  `set_device_type(DeviceType.ADB)`  ，后续整个执行链路自动走正确平台。  **切换平台的入口只有一个，不会出现"上半段走 ADB、下半段走 HDC"的混乱。**

### 3.3 iOS 为什么不用工厂

`DeviceFactory`  只覆盖了 ADB 和 HDC。iOS 的 ActionHandler 是独立的  `handler_ios.py`  ，直接 import xctest 模块，不经过工厂。

这不是设计缺陷——是 pragmatic 的选择：

|  | Android / HarmonyOS | iOS |
| --- | --- | --- |
| 通信方式 | subprocess 调 CLI | HTTP 请求 WDA |
| 连接参数 | `device_id: str` | `wda_url: str` + `session_id: str` + `device_id: str` |
| 状态管理 | 无状态（每条命令独立） | 有状态（WDA Session） |
| 函数签名 | 所有平台一致的简单签名 | 每个函数多 2-3 个参数 |

如果把 iOS 塞进 DeviceFactory，  `tap(x, y)`  的调用就得变成  `tap(x, y, wda_url, session_id)`  ——这 3 个额外参数对 Android 毫无意义，但每个调用方都得传。  **为了"统一"而污染接口，不如诚实地分叉。**

---

## 四、截图的三种姿势

截图是 Agent 的"眼睛"，每一步操作前都要截一次。这个操作的差异是三端最大的。

### 4.1 三端对比

![](20260608_三端统一：AndroidiOSHarmonyOS设备抽象层的设计与实现_assets/img_005_1811e5fac4216fee.png)

### 4.2 HarmonyOS 只出 JPEG 的坑

HDC 截图只支持 JPEG 格式——不管走  `screenshot`  还是  `snapshot_display`  命令，输出文件都是 JPEG。但下游的 VLM 模型都期望 PNG。所以必须做格式转换：

```

# HarmonyOS 截图的关键后处理img = Image.open(temp_path)      # PIL 自动检测 JPEG 格式（不管文件扩展名）width, height = img.sizebuffered = BytesIO()img.save(buffered, format="PNG") # 转存为 PNGbase64_data = base64.b64encode(buffered.getvalue()).decode("utf-8")

```

**JPEG 是有损压缩，转 PNG 不会恢复已丢失的信息。**  这意味着 HarmonyOS 的截图质量天然略低于 Android，在细小的文字和图标边界上可能影响模型识别精度。但实际测试中影响很小——模型对 JPEG artifact 有足够的鲁棒性。

### 4.3 HarmonyOS 的两套命令兼容

鸿蒙系统版本碎片化严重。较新版本用  `screenshot`  命令，旧版本只有  `snapshot_display`  ：

```

# 先试新命令result = _run_hdc_command(    hdc_prefix + ["shell", "screenshot", remote_path], ...)# 失败了就降级旧命令if"fail"in output.lower() or"error"in output.lower() or"not found"in output.lower():    result = _run_hdc_command(        hdc_prefix + ["shell", "snapshot_display", "-f", remote_path], ...    )

```

### 4.4 iOS 的双重降级链

iOS 截图有三层保障：

```
defget_screenshot(wda_url, session_id, device_id, timeout):# 第 1 层：WDA HTTP API（首选，最快）    screenshot = _get_screenshot_wda(wda_url, session_id, timeout)if screenshot:return screenshot# 第 2 层：idevicescreenshot CLI（WDA 挂了时的备胎）    screenshot = _get_screenshot_idevice(device_id, timeout)if screenshot:return screenshot# 第 3 层：给一张黑图，标记为 fallbackreturn _create_fallback_screenshot(is_sensitive=False)

```

WDA 是主力，但 WDA 本身是个运行在 iOS 设备上的进程——crash、被杀、网络抖动都可能导致 HTTP 请求失败。idevicescreenshot 走的是 USB 有线通道，更底层、更稳定，作为降级方案很合适。

### 4.5 敏感页面的处理

银行 App 的支付页、系统权限弹窗——这些页面系统级禁止截图。Android 的表现是  `adb screencap`  输出里出现  `Status: -1`  ：

```
output = result.stdout + result.stderrif"Status: -1"in output or"Failed"in output:return _create_fallback_screenshot(is_sensitive=True)# 返回黑图，标记 is_sensitive=True# 上层 Agent 看到这个标记就知道"截不到图，但这不是错误"

```

### 4.6 统一的返回类型

不管底层怎么截、截几次、格式怎么转，三个平台最终都返回同一个数据结构：

```
@dataclassclassScreenshot:    base64_data: str# PNG Base64    width: int# 像素宽    height: int# 像素高    is_sensitive: bool# 是否触发了敏感页面兜底

```

上层 ActionHandler 拿到的永远是  `Screenshot`  对象——完全不需要关心底层是 adb pull 还是 HTTP 还是 hdc recv。

---

## 五、触控操作：差异藏在细节里

### 5.1 Tap：从简单到复杂

```

# Android — 最简单的形式subprocess.run(["adb", "shell", "input", "tap", str(x), str(y)])# HarmonyOS — 不同命令，同样简洁subprocess.run(["hdc", "shell", "uitest", "uiInput", "click", str(x), str(y)])# iOS — 完全不同的世界：W3C WebDriver Actions APIrequests.post(url, json={"actions": [{"type": "pointer","id": "finger1","parameters": {"pointerType": "touch"},"actions": [            {"type": "pointerMove", "duration": 0, "x": x / SCALE_FACTOR, "y": y / SCALE_FACTOR},            {"type": "pointerDown", "button": 0},            {"type": "pause", "duration": 100},            {"type": "pointerUp", "button": 0},        ],    }]})

```

### 5.2 iOS 的 SCALE_FACTOR 之坑

这是做 iOS 设备抽象最容易踩的坑。

**WDA 的坐标空间不是物理像素，是逻辑点（points）。**  iPhone 14 Pro 的屏幕是 1179×2556 物理像素，但 WDA 的坐标空间是 393×852 点。换算关系是  `SCALE_FACTOR = 3`  。

```
SCALE_FACTOR = 3# 3x Retina 屏幕# ActionHandler 将归一化坐标换算为物理像素后：# element=[500, 500] 在 1179×2556 屏幕上 → (589, 1278)# 传给 iOS 的 tap 之前，必须再除以 SCALE_FACTOR：# (589/3, 1278/3) = (196, 426)  ← 这才是 WDA 期望的坐标# 如果忘了这一步，所有点击都会偏移 3 倍距离

```

这个 bug 的表现不是"点不到"，而是"点到的位置跟预期差了很远"——排查起来非常痛苦，因为 Android 和 HarmonyOS 都不需要这一步，你很容易忘了 iOS 多了一个除法。

### 5.3 Swipe：自动计算 duration

三端的 swipe 都支持自动计算 duration——基于滑动距离：

```

# Android: 距离换算时长，限制在 1000-2000msif duration_ms isNone:    dist_sq = (start_x - end_x) ** 2 + (start_y - end_y) ** 2    duration_ms = int(dist_sq / 1000)    duration_ms = max(1000, min(duration_ms, 2000))# HarmonyOS: 逻辑相同，但范围不同——限制在 500-1000ms（比 Android 快一倍）if duration_ms isNone:    dist_sq = (start_x - end_x) ** 2 + (start_y - end_y) ** 2    duration_ms = int(dist_sq / 1000)    duration_ms = max(500, min(duration_ms, 1000))# iOS: 逻辑相同，但单位是秒if duration isNone:    dist_sq = (start_x - end_x) ** 2 + (start_y - end_y) ** 2    duration = dist_sq / 1000000    duration = max(0.3, min(duration, 2.0))

```

**短距离滑动（如点击）duration 自动缩短，长距离滑动（如翻页）duration 自动拉长。**  这让模型不需要关心 swipe 的物理参数——只管给起点终点，duration 自动算。

### 5.4 iOS 没有 Back 键

Android 和 HarmonyOS 有物理/虚拟返回键，iOS 没有。iOS 的  `back()`  实际上是用 WDA 模拟一个左边缘右滑手势：

```
defback(wda_url, session_id, delay=1.0):# 模拟 iOS 的"从屏幕左边缘向右滑动"手势    payload = {"fromX": 0,  "fromY": 640,"toX": 400,  "toY": 640,"duration": 0.3,    }    requests.post(wda_url + "/wda/dragfromtoforduration", json=payload)

```

**这个实现有一个已知局限：**  如果 App 没有实现左边缘返回手势（比如游戏或自定义导航的 App），这个  `back()`  就是无效的。但这是 iOS 平台的固有限制，设备抽象层无法解决。  **能做的只是在文档里标注。**

### 5.5 HarmonyOS longClick 不支持自定义 duration

```

# Android 的 long_press 可以控制时长：subprocess.run(    ["adb", "shell", "input", "swipe", str(x), str(y), str(x), str(y), str(duration_ms)])# 起终点相同的 swipe = 长按，duration_ms 表示按多久# HarmonyOS 的 longClick 是固定时长的：subprocess.run(    ["hdc", "shell", "uitest", "uiInput", "longClick", str(x), str(y)])# duration_ms 参数在这里不起作用

```

这种差异在 API 层面无法抹平。设计策略是：  **函数签名保持一致（都接受 duration_ms），但在 HarmonyOS 的实现里注释说明 “此参数在当前版本不生效”。**  上层调用方不需要做任何判断。

---

## 六、文本输入：最复杂的跨平台差异

如果说截图和触控的差异只是"命令不一样"，那文本输入就是"完全不同的三套机制"。这是整个设备抽象层中最复杂的模块。

### 6.1 三端对比

| 维度 | Android | iOS | HarmonyOS |
| --- | --- | --- | --- |
| 输入方式 | ADBKeyboard 第三方输入法 | WDA `/wda/keys` HTTP API | `uitest uiInput text "xxx"` |
| 中文支持 | ❌ 原生不支持 → Base64 编码绕过 | ✅ 原生支持 | ✅ 原生支持 |
| 清除文本 | `ADB_CLEAR_TEXT` Broadcast | 获取 active element → clear → 降级退格×100 | Ctrl+A + Delete 组合键 |
| 键盘切换 | 需要：记录当前 IME → 切 ADBKeyboard → 用完恢复 | 不需要 | 不需要 |
| 多行文本 | 需要额外处理 | ✅ 原生支持 | 拆分 + 逐行发 ENTER keyEvent |

### 6.2 Android：绕不开的 ADBKeyboard

Android 的  `adb shell input text`  只能输入 ASCII 字符。中文、emoji、特殊符号一概不行。解决方案是借助 ADBKeyboard——一个专门为自动化设计的第三方输入法：

```
deftype_text(text: str, device_id: str | None = None) -> None:    encoded_text = base64.b64encode(text.encode("utf-8")).decode("utf-8")    subprocess.run(        adb_prefix + ["shell", "am", "broadcast","-a", "ADB_INPUT_B64","--es", "msg", encoded_text,        ], ...    )
```

但更复杂的是输入法切换——用户手机上默认是搜狗/讯飞/系统键盘，自动化执行时需要临时切换到 ADBKeyboard，用完再切回去：

```
defdetect_and_set_adb_keyboard(device_id):# 1. 记录用户当前的输入法    current_ime = subprocess.run(        adb_prefix + ["shell", "settings", "get", "secure", "default_input_method"], ...    ).stdout.strip()# 2. 切换到 ADBKeyboardif"com.android.adbkeyboard/.AdbIME"notin current_ime:        subprocess.run(            adb_prefix + ["shell", "ime", "set", "com.android.adbkeyboard/.AdbIME"], ...        )return current_ime  # 3. 返回原始 IME，供 restore_keyboard 使用

```

整个输入流程是：

```
检测当前输入法 → 切换到 ADBKeyboard → 清除文本 → Base64 输入 → 恢复原输入法
```

**每一步都可能失败。**  用户会看到键盘短暂切换——这是一个无法消除的体验瑕疵，但只要比"中文输入乱码"好，就可以接受。

### 6.3 iOS：最完善的文本输入

iOS 的文本输入通过 WDA 的  `/wda/keys`  端点，原生支持中文，不需要任何第三方工具：

```
deftype_text(text: str, wda_url, session_id, frequency=60):    requests.post(        wda_url + "/wda/keys",        json={"value": list(text), "frequency": frequency}  # 把文本拆成字符列表    )

```

清除文本先尝试获取 active element 调  `clear()`  ，失败了就发 100 次退格键兜底：

```
defclear_text(wda_url, session_id):# 第 1 层：获取当前焦点元素 → 调 clear    response = requests.get(wda_url + "/element/active")    element_id = response.json()["value"].get("ELEMENT")if element_id:        requests.post(wda_url + f"/element/{element_id}/clear")# 第 2 层：降级方案——发 100 次退格键    _clear_with_backspace(wda_url, session_id, max_backspaces=100)

```

### 6.4 HarmonyOS：出人意料的友好

HarmonyOS 的  `uitest uiInput text`  是三个平台中对中文最友好的——直接用，不需要任何第三方工具：

```
deftype_text(text: str, device_id=None):if'\n'in text:# 多行文本：逐行输入 + 行间插入 ENTER        lines = text.split('\n')for i, line inenumerate(lines):if line:                _run_hdc_command(                    hdc_prefix + ["shell", "uitest", "uiInput", "text", line]                )if i < len(lines) - 1:                _run_hdc_command(                    hdc_prefix + ["shell", "uitest", "uiInput", "keyEvent", "2054"]# 2054 是 HarmonyOS 的 ENTER 键码                )else:        _run_hdc_command(            hdc_prefix + ["shell", "uitest", "uiInput", "text", text]        )

```

清除文本用组合键 Ctrl+A(2072+2017) + Delete(2055)，比 iOS 的 100 次退格优雅得多。

**一个反直觉的结论：在文本输入这个维度上，HarmonyOS 的自动化友好度 > iOS > Android。**  Android 被  `adb shell input text`  的 ASCII-only 限制拖累，必须依赖第三方输入法。

---

## 七、应用管理：三套不同的标识体系

移动端自动化的第一步就是"打开/关闭某个应用"。但"应用"这个概念在三端的标识方式完全不同：

```

# Android: 包名 (package name)adb shell am force-stop com.tencent.mmadb shell monkey -p com.tencent.mm -c android.intent.category.LAUNCHER 1# iOS: Bundle IDrequests.post(wda_url + "/wda/apps/terminate", json={"bundleId": "com.tencent.xin"})requests.post(wda_url + "/wda/apps/launch",   json={"bundleId": "com.tencent.xin"})# HarmonyOS: 需要 bundle + ability 两个参数！hdc shell aa start -b com.tencent.mm -a EntryAbility#                                    ^^^^^^^^^^^ 应用入口 Ability，默认名 EntryAbility#                                    但不同应用可能不同

```

这意味着应用配置是三套独立的字典：

```

# Android apps.pyAPP_PACKAGES = {"微信": "com.tencent.mm","微博": "com.sina.weibo",    ...}# iOS apps_ios.pyAPP_PACKAGES_IOS = {"微信": "com.tencent.xin",     # 注意：iOS 的 bundle ID 和 Android 包名不同！"微博": "com.sina.weibo",    ...}# HarmonyOS apps_harmonyos.pyAPP_PACKAGES = {"微信": "com.tencent.mm",    ...}APP_ABILITIES = {"com.tencent.mm": "EntryAbility",  # 大部分应用默认这个"com.example.app": "MainAbility",  # 有些应用不同    ...}

```

**应用标识体系无法统一。**  Android 的包名、iOS 的 Bundle ID、HarmonyOS 的 Bundle+Ability，这是三个平台的设计决定，设备抽象层能做的只是：对上暴露统一的  `launch_app("微信")`  接口，对内各自查自己的字典。

---

## 八、获取当前 App：三种"我是谁"

Agent 每步操作前要确认"现在在哪个 App 里"——如果当前在桌面，要操作的 App 却没启动，需要先 launch。这个看似简单的查询，三个平台用了三种完全不同的工具：

```

# Android: 解析 dumpsys windowresult = subprocess.run(["adb", "shell", "dumpsys", "window"], ...)for line in output.split("\n"):if"mCurrentFocus"in line or"mFocusedApp"in line:for app_name, package in APP_PACKAGES.items():if package in line:return app_name# iOS: 调 WDA activeAppInfo APIresponse = requests.get(f"{wda_url}/wda/activeAppInfo")bundle_id = response.json()["value"]["bundleId"]for app_name, package in APP_PACKAGES.items():if package == bundle_id:return app_name# HarmonyOS: 用 hidumper 查 WindowManagerServiceresult = subprocess.run(    ["hdc", "shell", "hidumper", "-s", "WindowManagerService", "-a", "-a"], ...)for line in output.split("\n"):if"focused"in line.lower() or"current"in line.lower():for app_name, package in APP_PACKAGES.items():if package in line:return app_name

```

三条路径，同一个返回值：App 名称字符串（如  `"微信"`  ）或  `"System Home"`  。

---

## 九、上层 ActionHandler：平台无关的最后一步

有了设备抽象层，上层 Handler 的代码就干净了。Android 和 HarmonyOS 共用一个  `handler.py`  ：

```

# handler.py - Android / HarmonyOS 共用from ..device_factory import get_device_factoryclassActionHandler:def_handle_tap(self, action, screen_width, screen_height):        x, y = self._convert_relative_to_absolute(            action["element"], screen_width, screen_height        )        device_factory = get_device_factory()      # 全局单例        device_factory.tap(x, y, self.device_id)   # 不关心底层是 adb 还是 hdcdef_handle_swipe(self, action, screen_width, screen_height):        start_x, start_y = self._convert_relative_to_absolute(...)        end_x, end_y = self._convert_relative_to_absolute(...)        device_factory = get_device_factory()        device_factory.swipe(start_x, start_y, end_x, end_y, device_id=self.device_id)def_handle_type(self, action, screen_width, screen_height):        text = action.get("text", "")        device_factory = get_device_factory()        original_ime = device_factory.detect_and_set_adb_keyboard(self.device_id)        device_factory.clear_text(self.device_id)        device_factory.type_text(text, self.device_id)        device_factory.restore_keyboard(original_ime, self.device_id)

```

Handler 的核心操作（tap/swipe/type/back/home）没有任何  `if android ... elif harmonyos ...`  的分支。唯一的例外是  `_send_keyevent`  ——HarmonyOS 的 ENTER 键码是 2054，和 Android 完全不同，只能分支处理。  **但 95% 的平台差异已被 DeviceFactory 和模块级接口吃掉。**

iOS 的 Handler 是独立的  `handler_ios.py`  ，直接 import xctest 模块。但对外暴露的  `execute(action, screen_width, screen_height) → ActionResult`  接口和 Android Handler 一致——上层 Agent 只需要知道用哪个 Handler 实例。

---

## 十、踩过的坑

每条坑背后都有一个让你调了一下午的 bug：

| 坑 | 现象 | 原因 | 解决 |
| --- | --- | --- | --- |
| iOS 坐标偏移 3 倍 | 点击位置跟预期差了十万八千里 | WDA 用逻辑点（points），不是物理像素；需要除以 SCALE_FACTOR=3 | 所有 iOS 坐标操作统一 `/3` |
| HarmonyOS 截图发黑 | VLM 收到的图是全黑的 | HDC 输出 JPEG 格式，而某些下游工具直接当 PNG 读 | PIL 读取 JPEG → 重编码为 PNG |
| Android 中文输入乱码 | 中文变方框、变空、变 `???` | `adb shell input text` 只支持 ASCII | Base64 编码 + ADBKeyboard Broadcast |
| HarmonyOS App 启动失败 | `aa start` 报错启动不了 | 只传了 bundle 名，缺少 ability 参数 | 增加 `APP_ABILITIES` 字典，默认 `EntryAbility` |
| iOS kill App 偶发失败 | WDA terminate 返回 200 但 App 没退 | WDA terminate API 在 iOS 17+ 行为有变化 | 增加 `tidevice kill` 降级方案 |
| HDC 截图命令不存在 | `screenshot` 返回 “not found” | 新版鸿蒙用 `screenshot` ，旧版只有 `snapshot_display` | 先试新命令，失败自动降级旧命令 |
| Android 截图敏感页面 | `adb pull` 拉不到文件 | 银行/支付页面系统级禁止截图 | 检测 `Status: -1` ，返回黑图 + `is_sensitive=True` |
| iOS WDA 失联 | HTTP 请求超时 | WDA 进程 crash 或被 iOS 系统 kill | 降级 idevicescreenshot → 再降级黑图 |
| HDC HarmonyOS 多设备 | `-s` 参数不生效 | HDC 的设备指定参数是 `-t` ，不是 `-s` （ADB 用 `-s` ） | 每个平台维护自己的 prefix 函数 |

---

## 十一、设计原则总结

### 11.1 鸭子类型优于 ABC

同名模块级函数比抽象基类更适合跨平台设备抽象。接口灵活性优先于类型安全。iOS 的函数签名天然需要  `wda_url`  和  `session_id`  ——不强求所有平台统一。

### 11.2 懒加载避免依赖污染

跑 Android 不要 import iOS 的依赖。每个平台模块在第一次调用时才加载。一个进程只跑一个平台，不需要同时装三套工具链。

### 11.3 不要强行统一

如果某个平台的行为跟其他平台有本质差异（如 iOS 没有物理 Back 键），文档化差异比 hack 模拟更好。  **抽象层的职责是隐藏"不需要知道的差异"，不是消灭"所有差异"。**

### 11.4 每层兜底、层层降级

截图：WDA → idevicescreenshot → 黑图。 启动：WDA terminate → tidevice kill → 报错。 截图命令：screenshot → snapshot_display → 黑图。

**确定性降级比"尽最大努力但不保证"更可靠。**

### 11.5 全局单例 + 启动时设一次

`set_device_type()`  只在 Agent 启动时调用一次。切换平台的入口唯一，不会出现"上半段走 ADB、下半段走 HDC"的混乱。

### 11.6 代码容错优先于协议完美

HDC 的  `longClick`  不支持自定义 duration、iOS 的  `back()`  在某些 App 里不生效——这些差异在协议层无法抹平。函数签名保持一致，差异写在注释里，比强行 hack 更好。

---

## 十二、总结

**设备抽象层的本质不是写一个完美的接口，而是把"不完美的三套协议"装进"足够好的统一入口"里。**  上层 Agent 写一次，三端跑——不需要知道底下是 adb shell 还是 HTTP POST 还是 hdc uitest。

---

**相关文章：**

- •
  [《AI 自动化与传统自动化：移动端 UI 测试的两条路》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487415&idx=1&sn=120af393c7116ebb5d2171783e3afe87&scene=21#wechat_redirect)
- •
  [《AI 自动化 Agent 框架：移动端 UI 测试的架构设计与模式选择》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487401&idx=1&sn=fefde65550005642a3a2de19892e4f3d&scene=21#wechat_redirect)
- •
  [《Agent 提示词工程：移动端 UI 测试的 Prompt 设计实践》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487393&idx=1&sn=272a981127a9f1573e1a53f45a5177c3&scene=21#wechat_redirect)
- •
  [《AI 自动化 Agent 框架：移动端 UI 测试的架构设计与模式选择》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487388&idx=1&sn=73945efa19c200175600384f0798fef1&scene=21#wechat_redirect)
- •
  [《Agent 提示词工程：移动端 UI 测试的 Prompt 设计实践》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487377&idx=1&sn=48cee43cc13b698a69d956d94a5e2acf&scene=21#wechat_redirect)
- •
  [《AI 自动化 Agent 框架：移动端 UI 测试的架构设计与模式选择》](https://mp.weixin.qq.com/s?__biz=Mzg3ODE4MTA4Mw==&mid=2247487366&idx=1&sn=8013e308cf2cb87cccbcb4227804fa09&scene=21#wechat_redirect)

预览时标签不可点
![]()

微信扫一扫   
 关注该公众号

继续滑动看下一个
轻触阅读原文
![](20260608_三端统一：AndroidiOSHarmonyOS设备抽象层的设计与实现_assets/img_007_b585214916937a92.png)
测试加
向上滑动看下一个

[知道了](javascript:;)

![]()
微信扫一扫
  
使用小程序
[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

[取消](javascript:void(0);)
[允许](javascript:void(0);)

×

分析

![]()
![](20260608_三端统一：AndroidiOSHarmonyOS设备抽象层的设计与实现_assets/img_010_b585214916937a92.png)

微信扫一扫可打开此内容，   
 使用完整服务

：
，
，
，
，
，
，
，
，
，
，
，
，
。
视频
小程序
赞
，轻点两下取消赞
在看
，轻点两下取消在看
分享
留言
收藏
听过